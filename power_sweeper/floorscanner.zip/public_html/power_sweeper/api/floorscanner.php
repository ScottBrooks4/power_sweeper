<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';

use PowerSweeper\FloorScanner\FloorplanImage;
use PowerSweeper\FloorScanner\RoomDetector;

header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => true,
        'name' => 'Floor Scanner',
        'accept' => ['png', 'jpeg', 'webp', 'gif', 'svg'],
        'upload_limits' => [
            'upload_max_filesize' => (string) ini_get('upload_max_filesize'),
            'post_max_size' => (string) ini_get('post_max_size'),
        ],
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    $blob = '';
    $name = 'floorplan.png';
    if (isset($_FILES['floorplan']) && is_array($_FILES['floorplan'])) {
        $file = $_FILES['floorplan'];
        $err = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err !== UPLOAD_ERR_OK) {
            $hint = match ($err) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'File exceeds upload limit',
                UPLOAD_ERR_PARTIAL => 'Partial upload',
                UPLOAD_ERR_NO_FILE => 'No floorplan uploaded',
                default => 'Upload failed (code ' . $err . ')',
            };
            throw new RuntimeException($hint);
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new RuntimeException('Invalid upload');
        }
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > 20 * 1024 * 1024) {
            throw new RuntimeException('Floorplan must be under 20 MB');
        }
        $blob = (string) file_get_contents($tmp);
        $name = (string) ($file['name'] ?? $name);
    } elseif (isset($_POST['sample']) && (string) $_POST['sample'] === '1') {
        $sample = dirname(__DIR__) . '/public/assets/sample-floorplan.png';
        if (!is_file($sample)) {
            $sample = dirname(__DIR__) . '/tests/fixtures/sample_floorplan.png';
        }
        if (!is_file($sample)) {
            throw new RuntimeException('Sample floorplan is not available');
        }
        $blob = (string) file_get_contents($sample);
        $name = 'sample-floorplan.png';
    } else {
        throw new RuntimeException('Drop a floorplan image to scan');
    }

    if ($blob === '') {
        throw new RuntimeException('Floorplan is empty');
    }

    $isSvg = FloorplanImage::looksLikeSvg($blob, $name);
    if (!$isSvg) {
        $info = @getimagesizefromstring($blob);
        if ($info === false) {
            throw new RuntimeException('File is not a recognized image or SVG');
        }
    }

    $detector = new RoomDetector();
    $result = $detector->detectBlob($blob, $name);
    $rooms = $result['rooms'];
    $roomCount = 0;
    $cubicleCount = 0;
    foreach ($rooms as $room) {
        if (($room['type'] ?? '') === 'cubicle') {
            $cubicleCount++;
        } else {
            $roomCount++;
        }
    }

    echo json_encode([
        'ok' => true,
        'filename' => $name,
        'width' => $result['width'],
        'height' => $result['height'],
        'room_count' => $roomCount,
        'cubicle_count' => $cubicleCount,
        'rooms' => $rooms,
        'overlay_data_url' => $result['overlay_data_url'],
        'overlay_png_data_url' => 'data:image/png;base64,' . base64_encode($result['overlay_png']),
        'format' => 'svg',
    ], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_SLASHES);
}
