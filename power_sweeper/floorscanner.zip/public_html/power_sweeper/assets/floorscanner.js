(() => {
  const cfg = window.FLOOR_SCANNER || {};
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');
  const browseBtn = document.getElementById('browseBtn');
  const fileLabel = document.getElementById('fileLabel');
  const scanBtn = document.getElementById('scanBtn');
  const sampleBtn = document.getElementById('sampleBtn');
  const statusEl = document.getElementById('status');
  const resultPanel = document.getElementById('resultPanel');
  const resultSummary = document.getElementById('resultSummary');
  const beforeImg = document.getElementById('beforeImg');
  const afterImg = document.getElementById('afterImg');
  const roomList = document.getElementById('roomList');
  const downloadLink = document.getElementById('downloadLink');

  let selectedFile = null;
  let beforeUrl = null;

  const setStatus = (text, isError = false) => {
    statusEl.textContent = text;
    statusEl.classList.toggle('is-error', isError);
  };

  const revokeBefore = () => {
    if (beforeUrl) {
      URL.revokeObjectURL(beforeUrl);
      beforeUrl = null;
    }
  };

  const setFile = (file) => {
    if (!file) {
      return;
    }
    if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|gif|svg)$/i.test(file.name || '')) {
      setStatus('Choose a floorplan (SVG, PNG, JPEG, or WebP).', true);
      return;
    }
    selectedFile = file;
    revokeBefore();
    beforeUrl = URL.createObjectURL(file);
    fileLabel.textContent = file.name || 'Floorplan ready';
    dropZone.classList.add('has-file');
    scanBtn.disabled = false;
    setStatus('Ready to scan');
  };

  const renderResult = (data, previewUrl) => {
    const rooms = data.rooms || [];
    resultSummary.textContent = `${data.room_count} room${data.room_count === 1 ? '' : 's'}, ${data.cubicle_count} cubicle${data.cubicle_count === 1 ? '' : 's'} · ${data.width}×${data.height}`;
    beforeImg.src = previewUrl;
    afterImg.src = data.overlay_data_url || data.overlay_png_data_url;
    downloadLink.href = data.overlay_data_url;
    downloadLink.download = 'floor-scanner.svg';
    roomList.replaceChildren();
    for (const room of rooms) {
      const li = document.createElement('li');
      li.className = 'room-card';
      li.dataset.type = room.type;
      const title = document.createElement('strong');
      title.textContent = room.label;
      const meta = document.createElement('span');
      meta.textContent = `${room.area_pct}% · ${room.bbox.width}×${room.bbox.height}px`;
      li.append(title, meta);
      roomList.append(li);
    }
    resultPanel.classList.remove('hidden');
  };

  const scan = async (file, { sample = false } = {}) => {
    scanBtn.disabled = true;
    sampleBtn.disabled = true;
    setStatus(sample ? 'Scanning sample…' : 'Scanning…');
    const body = new FormData();
    if (sample && !file) {
      body.set('sample', '1');
    } else {
      body.set('floorplan', file, file.name || 'floorplan.png');
    }
    try {
      const res = await fetch(cfg.apiScan, { method: 'POST', body });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || 'Scan failed');
      }
      const preview = file && beforeUrl ? beforeUrl : (cfg.sampleImage || data.overlay_data_url);
      if (sample && cfg.sampleImage) {
        beforeImg.src = cfg.sampleImage;
      }
      renderResult(data, sample ? cfg.sampleImage : preview);
      setStatus(`Found ${data.room_count + data.cubicle_count} spaces`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Scan failed', true);
    } finally {
      scanBtn.disabled = !selectedFile;
      sampleBtn.disabled = false;
    }
  };

  dropZone.addEventListener('click', () => fileInput.click());
  browseBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    fileInput.click();
  });
  fileInput.addEventListener('change', () => {
    const file = fileInput.files && fileInput.files[0];
    if (file) {
      setFile(file);
    }
  });
  ;['dragenter', 'dragover'].forEach((type) => {
    dropZone.addEventListener(type, (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
  });
  ;['dragleave', 'drop'].forEach((type) => {
    dropZone.addEventListener(type, (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });
  dropZone.addEventListener('drop', (e) => {
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) {
      setFile(file);
    }
  });
  dropZone.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fileInput.click();
    }
  });
  scanBtn.addEventListener('click', () => {
    if (selectedFile) {
      scan(selectedFile);
    }
  });
  sampleBtn.addEventListener('click', () => scan(null, { sample: true }));
})();
