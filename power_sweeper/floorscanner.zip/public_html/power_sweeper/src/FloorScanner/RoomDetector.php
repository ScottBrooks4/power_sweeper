<?php

declare(strict_types=1);

namespace PowerSweeper\FloorScanner;

/**
 * Detect rooms and cubicles, then paint each as an axis-aligned rectangle.
 * Furniture is ignored when finding walls; it stays visible on top of the fill.
 */
final class RoomDetector
{
    public const OVERLAY_R = 138;
    public const OVERLAY_G = 207;
    public const OVERLAY_B = 194;

    private const MAX_PROCESS = 900;

    /**
     * @return array{
     *   width: int,
     *   height: int,
     *   rooms: list<array<string, mixed>>,
     *   overlay_png: string,
     *   overlay_svg: string,
     *   overlay_data_url: string
     * }
     */
    public function detectFile(string $path): array
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new \RuntimeException('Floorplan not found');
        }
        $raw = file_get_contents($path);
        if ($raw === false || $raw === '') {
            throw new \RuntimeException('Floorplan is empty');
        }
        return $this->detectBlob($raw, basename($path));
    }

    /**
     * @return array{
     *   width: int,
     *   height: int,
     *   rooms: list<array<string, mixed>>,
     *   overlay_png: string,
     *   overlay_svg: string,
     *   overlay_data_url: string
     * }
     */
    public function detectBlob(string $blob, string $filename = ''): array
    {
        $loaded = FloorplanImage::loadBlob($blob, $filename);
        $source = $loaded['image'];
        try {
            return $this->detectImage($source, $loaded['svg']);
        } finally {
            imagedestroy($source);
        }
    }

    /**
     * @return array{
     *   width: int,
     *   height: int,
     *   rooms: list<array<string, mixed>>,
     *   overlay_png: string,
     *   overlay_svg: string,
     *   overlay_data_url: string
     * }
     */
    public function detectImage(\GdImage $source, ?string $sourceSvg = null): array
    {
        $srcW = imagesx($source);
        $srcH = imagesy($source);
        if ($srcW < 16 || $srcH < 16) {
            throw new \RuntimeException('Floorplan is too small');
        }

        $scale = 1.0;
        $work = $source;
        $ownsWork = false;
        $maxSide = max($srcW, $srcH);
        if ($maxSide > self::MAX_PROCESS) {
            $scale = self::MAX_PROCESS / $maxSide;
            $workW = max(80, (int) round($srcW * $scale));
            $workH = max(80, (int) round($srcH * $scale));
            $work = imagecreatetruecolor($workW, $workH);
            if (!$work instanceof \GdImage) {
                throw new \RuntimeException('Could not scale floorplan');
            }
            imagecopyresampled($work, $source, 0, 0, 0, 0, $workW, $workH, $srcW, $srcH);
            $ownsWork = true;
        }

        try {
            $w = imagesx($work);
            $h = imagesy($work);
            $n = $w * $h;
            $walls = $this->wallMask($work, $w, $h);
            $closeR = max(5, (int) round(min($w, $h) * 0.013));
            $closed = $this->dilate($walls, $w, $h, $closeR);
            $cores = $this->invert($this->floodFromBorder($closed, $w, $h));
            $minCore = max(200, (int) ($n * 0.0007));
            $rects = $this->rectanglesFromCores($cores, $walls, $w, $h, $minCore);
            $inv = $scale > 0 ? 1.0 / $scale : 1.0;
            $srcRects = [];
            foreach ($rects as $r) {
                $srcRects[] = [
                    (int) floor($r[0] * $inv),
                    (int) floor($r[1] * $inv),
                    (int) max($r[0], ceil(($r[2] + 1) * $inv) - 1),
                    (int) max($r[1], ceil(($r[3] + 1) * $inv) - 1),
                ];
            }
            $srcWalls = $this->wallMask($source, $srcW, $srcH);
            $rooms = $this->summarizeRects($srcRects, $srcW, $srcH);
            $overlay = $this->renderOverlay($source, $srcRects, $srcWalls, $srcW, $srcH);
            $png = $this->gdToPng($overlay);
            imagedestroy($overlay);
            $svg = $this->buildSvg($source, $srcRects, $srcW, $srcH, $sourceSvg);

            return [
                'width' => $srcW,
                'height' => $srcH,
                'rooms' => $rooms,
                'overlay_png' => $png,
                'overlay_svg' => $svg,
                'overlay_data_url' => 'data:image/svg+xml;base64,' . base64_encode($svg),
            ];
        } finally {
            if ($ownsWork) {
                imagedestroy($work);
            }
        }
    }

    /**
     * After interiors are filled, cover each filled region with a rectangle
     * so furniture inside the room is included in the fill.
     *
     * @param list<int> $cores
     * @param list<int> $walls
     * @return list<array{0:int,1:int,2:int,3:int}>
     */
    private function rectanglesFromCores(array $cores, array $walls, int $w, int $h, int $minCore): array
    {
        $n = $w * $h;
        $primary = [];
        $extra = [];
        foreach ($this->components($cores, $w, $h, $minCore) as $comp) {
            $bb = $comp['bbox'];
            $boxA = $this->rectArea($bb);
            $ratio = $boxA > 0 ? $comp['area'] / $boxA : 0.0;
            $openPlan = $comp['area'] >= (int) ($n * 0.08) || $ratio < 0.42;
            if (!$openPlan) {
                $primary[] = $this->snapToWalls($bb, $walls, $w, $h);
                continue;
            }
            $split = $this->splitOpenPlan($comp['mask'], $w, $h);
            if ($split === []) {
                $extra[] = $this->snapToWalls($bb, $walls, $w, $h);
                continue;
            }
            foreach ($split as $part) {
                $extra[] = $this->snapToWalls($part, $walls, $w, $h);
            }
        }

        $kept = $this->cullRects($primary, 1800, 28);
        foreach ($this->cullRects($extra, 3000, 36) as $rect) {
            $overlaps = false;
            foreach ($kept as $host) {
                if ($this->overlapFrac($rect, $host) > 0.35) {
                    $overlaps = true;
                    break;
                }
            }
            if (!$overlaps) {
                $kept[] = $rect;
            }
        }
        return $kept;
    }

    /**
     * @param list<int> $mask
     * @return list<array{0:int,1:int,2:int,3:int}>
     */
    private function splitOpenPlan(array $mask, int $w, int $h): array
    {
        foreach ([12, 16, 20, 24] as $rad) {
            $parts = $this->components($this->opening($mask, $w, $h, $rad), $w, $h, 2500);
            if (count($parts) >= 2) {
                return array_map(static fn (array $p): array => $p['bbox'], $parts);
            }
        }
        return [];
    }

    /**
     * @param list<array{0:int,1:int,2:int,3:int}> $rects
     * @return list<array{0:int,1:int,2:int,3:int}>
     */
    private function cullRects(array $rects, int $minArea, int $minSide): array
    {
        usort($rects, fn (array $a, array $b): int => $this->rectArea($b) <=> $this->rectArea($a));
        $kept = [];
        foreach ($rects as $rect) {
            $area = $this->rectArea($rect);
            $bw = $rect[2] - $rect[0] + 1;
            $bh = $rect[3] - $rect[1] + 1;
            if ($area < $minArea || min($bw, $bh) < $minSide) {
                continue;
            }
            $cx = intdiv($rect[0] + $rect[2], 2);
            $cy = intdiv($rect[1] + $rect[3], 2);
            $skip = false;
            foreach ($kept as $host) {
                if ($this->overlapFrac($rect, $host) > 0.4) {
                    $skip = true;
                    break;
                }
                if (
                    $cx >= $host[0] && $cx <= $host[2]
                    && $cy >= $host[1] && $cy <= $host[3]
                    && $area < (int) ($this->rectArea($host) * 0.4)
                ) {
                    $skip = true;
                    break;
                }
            }
            if (!$skip) {
                $kept[] = $rect;
            }
        }
        return $kept;
    }

    /**
     * @param array{0:int,1:int,2:int,3:int} $bb
     * @param list<int> $walls
     * @return array{0:int,1:int,2:int,3:int}
     */
    private function snapToWalls(array $bb, array $walls, int $w, int $h, int $maxStep = 16): array
    {
        [$x0, $y0, $x1, $y1] = $bb;
        for ($i = 0; $i < $maxStep && $x0 > 0; $i++) {
            if ($this->colWallFrac($walls, $w, $h, $x0 - 1, $y0, $y1) > 0.28) {
                break;
            }
            $x0--;
        }
        for ($i = 0; $i < $maxStep && $x1 < $w - 1; $i++) {
            if ($this->colWallFrac($walls, $w, $h, $x1 + 1, $y0, $y1) > 0.28) {
                break;
            }
            $x1++;
        }
        for ($i = 0; $i < $maxStep && $y0 > 0; $i++) {
            if ($this->rowWallFrac($walls, $w, $x0, $x1, $y0 - 1) > 0.28) {
                break;
            }
            $y0--;
        }
        for ($i = 0; $i < $maxStep && $y1 < $h - 1; $i++) {
            if ($this->rowWallFrac($walls, $w, $x0, $x1, $y1 + 1) > 0.28) {
                break;
            }
            $y1++;
        }
        return [$x0, $y0, $x1, $y1];
    }

    /**
     * @param list<int> $walls
     */
    private function colWallFrac(array $walls, int $w, int $h, int $x, int $y0, int $y1): float
    {
        $y0 = max(0, $y0);
        $y1 = min($h - 1, $y1);
        if ($y1 < $y0) {
            return 0.0;
        }
        $hits = 0;
        $n = 0;
        for ($y = $y0; $y <= $y1; $y++) {
            $n++;
            if ($walls[$y * $w + $x] === 1) {
                $hits++;
            }
        }
        return $n > 0 ? $hits / $n : 0.0;
    }

    /**
     * @param list<int> $walls
     */
    private function rowWallFrac(array $walls, int $w, int $x0, int $x1, int $y): float
    {
        $x0 = max(0, $x0);
        $x1 = min($w - 1, $x1);
        if ($x1 < $x0) {
            return 0.0;
        }
        $hits = 0;
        $n = 0;
        $row = $y * $w;
        for ($x = $x0; $x <= $x1; $x++) {
            $n++;
            if ($walls[$row + $x] === 1) {
                $hits++;
            }
        }
        return $n > 0 ? $hits / $n : 0.0;
    }

    /**
     * Mid-gray walls only — skip dark furniture ink.
     *
     * @return list<int>
     */
    private function wallMask(\GdImage $im, int $w, int $h): array
    {
        $n = $w * $h;
        $mask = array_fill(0, $n, 0);
        for ($y = 0; $y < $h; $y++) {
            for ($x = 0; $x < $w; $x++) {
                $rgb = imagecolorat($im, $x, $y);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                $lum = ($r + $g + $b) / 3.0;
                $chroma = max(abs($r - $g), abs($g - $b), abs($r - $b));
                if ($lum >= 70 && $lum <= 185 && $chroma <= 28) {
                    $mask[$y * $w + $x] = 1;
                }
            }
        }
        return $mask;
    }

    /**
     * @param list<int> $mask
     * @return list<int>
     */
    private function dilate(array $mask, int $w, int $h, int $radius): array
    {
        if ($radius <= 0) {
            return $mask;
        }
        $n = $w * $h;
        $tmp = array_fill(0, $n, 0);
        for ($y = 0; $y < $h; $y++) {
            $row = $y * $w;
            $count = 0;
            for ($x = 0; $x < $w + $radius; $x++) {
                if ($x < $w && $mask[$row + $x] === 1) {
                    $count++;
                }
                $out = $x - $radius;
                $left = $out - $radius - 1;
                if ($left >= 0 && $mask[$row + $left] === 1) {
                    $count--;
                }
                if ($out >= 0 && $out < $w) {
                    $tmp[$row + $out] = $count > 0 ? 1 : 0;
                }
            }
        }
        $out = array_fill(0, $n, 0);
        for ($x = 0; $x < $w; $x++) {
            $count = 0;
            for ($y = 0; $y < $h + $radius; $y++) {
                if ($y < $h && $tmp[$y * $w + $x] === 1) {
                    $count++;
                }
                $oy = $y - $radius;
                $top = $oy - $radius - 1;
                if ($top >= 0 && $tmp[$top * $w + $x] === 1) {
                    $count--;
                }
                if ($oy >= 0 && $oy < $h) {
                    $out[$oy * $w + $x] = $count > 0 ? 1 : 0;
                }
            }
        }
        return $out;
    }

    /**
     * @param list<int> $mask
     * @return list<int>
     */
    private function erode(array $mask, int $w, int $h, int $radius): array
    {
        return $this->invert($this->dilate($this->invert($mask), $w, $h, $radius));
    }

    /**
     * @param list<int> $mask
     * @return list<int>
     */
    private function opening(array $mask, int $w, int $h, int $radius): array
    {
        return $this->dilate($this->erode($mask, $w, $h, $radius), $w, $h, $radius);
    }

    /**
     * @param list<int> $mask
     * @return list<int>
     */
    private function invert(array $mask): array
    {
        $n = count($mask);
        $out = array_fill(0, $n, 0);
        for ($i = 0; $i < $n; $i++) {
            $out[$i] = $mask[$i] === 1 ? 0 : 1;
        }
        return $out;
    }

    /**
     * @param list<int> $blocked
     * @return list<int>
     */
    private function floodFromBorder(array $blocked, int $w, int $h): array
    {
        $seen = $blocked;
        $qx = [];
        $qy = [];
        $qs = 0;
        $enqueue = static function (int $x, int $y) use ($w, $h, &$seen, &$qx, &$qy, &$qs): void {
            if ($x < 0 || $y < 0 || $x >= $w || $y >= $h) {
                return;
            }
            $i = $y * $w + $x;
            if ($seen[$i] === 1) {
                return;
            }
            $seen[$i] = 1;
            $qx[] = $x;
            $qy[] = $y;
            $qs++;
        };
        for ($x = 0; $x < $w; $x++) {
            $enqueue($x, 0);
            $enqueue($x, $h - 1);
        }
        for ($y = 0; $y < $h; $y++) {
            $enqueue(0, $y);
            $enqueue($w - 1, $y);
        }
        $qi = 0;
        while ($qi < $qs) {
            $x = $qx[$qi];
            $y = $qy[$qi];
            $qi++;
            $enqueue($x - 1, $y);
            $enqueue($x + 1, $y);
            $enqueue($x, $y - 1);
            $enqueue($x, $y + 1);
        }
        return $seen;
    }

    /**
     * @param list<int> $free
     * @return list<array{mask: list<int>, area: int, bbox: array{0:int,1:int,2:int,3:int}}>
     */
    private function components(array $free, int $w, int $h, int $minArea): array
    {
        $n = $w * $h;
        $seen = array_fill(0, $n, 0);
        $out = [];
        for ($i = 0; $i < $n; $i++) {
            if ($free[$i] !== 1 || $seen[$i] === 1) {
                continue;
            }
            $qx = [$i % $w];
            $qy = [intdiv($i, $w)];
            $seen[$i] = 1;
            $pixels = [$i];
            $qs = 1;
            $qi = 0;
            $minX = $qx[0];
            $maxX = $qx[0];
            $minY = $qy[0];
            $maxY = $qy[0];
            while ($qi < $qs) {
                $x = $qx[$qi];
                $y = $qy[$qi];
                $qi++;
                foreach ([[$x - 1, $y], [$x + 1, $y], [$x, $y - 1], [$x, $y + 1]] as [$nx, $ny]) {
                    if ($nx < 0 || $ny < 0 || $nx >= $w || $ny >= $h) {
                        continue;
                    }
                    $ni = $ny * $w + $nx;
                    if ($free[$ni] !== 1 || $seen[$ni] === 1) {
                        continue;
                    }
                    $seen[$ni] = 1;
                    $qx[] = $nx;
                    $qy[] = $ny;
                    $pixels[] = $ni;
                    $qs++;
                    $minX = min($minX, $nx);
                    $maxX = max($maxX, $nx);
                    $minY = min($minY, $ny);
                    $maxY = max($maxY, $ny);
                }
            }
            $area = count($pixels);
            if ($area < $minArea) {
                continue;
            }
            $mask = array_fill(0, $n, 0);
            foreach ($pixels as $pi) {
                $mask[$pi] = 1;
            }
            $out[] = [
                'mask' => $mask,
                'area' => $area,
                'bbox' => [$minX, $minY, $maxX, $maxY],
            ];
        }
        return $out;
    }

    /**
     * @param array{0:int,1:int,2:int,3:int} $r
     */
    private function rectArea(array $r): int
    {
        return max(0, $r[2] - $r[0] + 1) * max(0, $r[3] - $r[1] + 1);
    }

    /**
     * @param array{0:int,1:int,2:int,3:int} $a
     * @param array{0:int,1:int,2:int,3:int} $b
     */
    private function overlapFrac(array $a, array $b): float
    {
        $x0 = max($a[0], $b[0]);
        $y0 = max($a[1], $b[1]);
        $x1 = min($a[2], $b[2]);
        $y1 = min($a[3], $b[3]);
        if ($x0 > $x1 || $y0 > $y1) {
            return 0.0;
        }
        $area = $this->rectArea($a);
        return $area > 0 ? (($x1 - $x0 + 1) * ($y1 - $y0 + 1)) / $area : 0.0;
    }

    /**
     * @param list<array{0:int,1:int,2:int,3:int}> $rects
     * @return list<array<string, mixed>>
     */
    private function summarizeRects(array $rects, int $w, int $h): array
    {
        usort($rects, fn (array $a, array $b): int => $this->rectArea($b) <=> $this->rectArea($a));
        $total = 0;
        foreach ($rects as $r) {
            $total += $this->rectArea($r);
        }
        $cubiclePx = max(900, (int) ($w * $h * 0.014));
        $rooms = [];
        foreach ($rects as $idx => $r) {
            $area = $this->rectArea($r);
            $type = $area < $cubiclePx ? 'cubicle' : 'room';
            $rooms[] = [
                'id' => $idx + 1,
                'type' => $type,
                'label' => ($type === 'cubicle' ? 'Cubicle' : 'Room') . ' ' . ($idx + 1),
                'area_px' => $area,
                'area_pct' => $total > 0 ? round(100.0 * $area / $total, 1) : 0.0,
                'bbox' => [
                    'x' => $r[0],
                    'y' => $r[1],
                    'width' => $r[2] - $r[0] + 1,
                    'height' => $r[3] - $r[1] + 1,
                ],
                'centroid' => [
                    'x' => intdiv($r[0] + $r[2], 2),
                    'y' => intdiv($r[1] + $r[3], 2),
                ],
            ];
        }
        return $rooms;
    }

    /**
     * @param list<array{0:int,1:int,2:int,3:int}> $rects
     * @param list<int> $walls
     */
    private function renderOverlay(\GdImage $source, array $rects, array $walls, int $w, int $h): \GdImage
    {
        $out = imagecreatetruecolor($w, $h);
        if (!$out instanceof \GdImage) {
            throw new \RuntimeException('Could not create overlay');
        }
        imagecopy($out, $source, 0, 0, 0, 0, $w, $h);
        $inside = array_fill(0, $w * $h, 0);
        foreach ($rects as $r) {
            for ($y = max(0, $r[1]); $y <= min($h - 1, $r[3]); $y++) {
                $row = $y * $w;
                for ($x = max(0, $r[0]); $x <= min($w - 1, $r[2]); $x++) {
                    $inside[$row + $x] = 1;
                }
            }
        }
        $fr = self::OVERLAY_R / 254.38;
        $fg = self::OVERLAY_G / 254.36;
        $fb = self::OVERLAY_B / 254.38;
        for ($y = 0; $y < $h; $y++) {
            for ($x = 0; $x < $w; $x++) {
                $i = $y * $w + $x;
                if ($inside[$i] !== 1 || $walls[$i] === 1) {
                    continue;
                }
                $rgb = imagecolorat($source, $x, $y);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                $lum = ($r + $g + $b) / 3.0;
                if ($lum >= 180) {
                    $nr = (int) max(0, min(255, (int) round($r * $fr)));
                    $ng = (int) max(0, min(255, (int) round($g * $fg)));
                    $nb = (int) max(0, min(255, (int) round($b * $fb)));
                    imagesetpixel($out, $x, $y, ($nr << 16) | ($ng << 8) | $nb);
                } elseif ($lum < 70) {
                    $nr = (int) max(0, min(255, (int) round($r * 0.72 + 8 * 0.28)));
                    $ng = (int) max(0, min(255, (int) round($g * 0.72 + 48 * 0.28)));
                    $nb = (int) max(0, min(255, (int) round($b * 0.72 + 40 * 0.28)));
                    imagesetpixel($out, $x, $y, ($nr << 16) | ($ng << 8) | $nb);
                }
            }
        }
        return $out;
    }

    /**
     * @param list<array{0:int,1:int,2:int,3:int}> $rects
     */
    private function buildSvg(\GdImage $source, array $rects, int $w, int $h, ?string $sourceSvg): string
    {
        $rectsXml = '';
        foreach ($rects as $r) {
            $rectsXml .= sprintf(
                '    <rect x="%d" y="%d" width="%d" height="%d"/>' . "\n",
                $r[0],
                $r[1],
                $r[2] - $r[0] + 1,
                $r[3] - $r[1] + 1
            );
        }
        $group = sprintf(
            "  <g fill=\"rgb(%d,%d,%d)\" style=\"mix-blend-mode:multiply\" pointer-events=\"none\">\n%s  </g>\n",
            self::OVERLAY_R,
            self::OVERLAY_G,
            self::OVERLAY_B,
            $rectsXml
        );
        if (is_string($sourceSvg) && $sourceSvg !== '') {
            return $this->injectRectsIntoSvg($sourceSvg, $group, $w, $h);
        }
        $origB64 = base64_encode($this->gdToPng($source));
        return sprintf(
            <<<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">
  <image href="data:image/png;base64,%s" width="%d" height="%d"/>
%s</svg>

SVG,
            $w,
            $h,
            $w,
            $h,
            $origB64,
            $w,
            $h,
            $group
        );
    }

    private function injectRectsIntoSvg(string $svg, string $group, int $w, int $h): string
    {
        $svg = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $svg) ?? $svg;
        $svg = preg_replace('/\\son[a-z]+\\s*=\\s*("[^"]*"|\'[^\']*\')/i', '', $svg) ?? $svg;
        $svg = trim($svg);
        if (preg_match('/<\\/svg\\s*>/i', $svg) === 1) {
            return (string) preg_replace('/<\\/svg\\s*>/i', rtrim($group) . "\n</svg>", $svg, 1);
        }
        return sprintf(
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\">\n%s\n%s</svg>\n",
            $w,
            $h,
            $w,
            $h,
            $svg,
            $group
        );
    }

    private function gdToPng(\GdImage $im): string
    {
        ob_start();
        imagepng($im, null, 6);
        $png = ob_get_clean();
        if (!is_string($png) || $png === '') {
            throw new \RuntimeException('Failed to encode overlay');
        }
        return $png;
    }
}
