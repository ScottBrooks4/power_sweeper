(() => {
	"use strict";

	const slides = Array.from(document.querySelectorAll(".slide"));
	const dotsEl = document.getElementById("dots");
	const posEl = document.getElementById("pos");
	const deck = document.getElementById("deck");
	let index = 0;
	let stegoMode = "zw";
	let labId = "predict";
	let eraIndex = 0;
	let structTab = "ab";
	const structState = {
		ab: { a: 5, b: 6, n: 40 },
		tag: { tag: "<li></li>", n: 60 },
		wave: { amp: 4, period: 6, len: 240, base: 5 },
	};
	const structDrafts = {}; // tab -> { expanded, mark }
	const labDrafts = {}; // lab id -> input string
	const peelPrefixDrafts = {};

	const METER_TIPS = {
		chars: "Number of JavaScript string characters (UTF‑16 code units in JS; emoji may count as 2).",
		bytes: "UTF‑8 byte length — what files and most compressors actually count.",
		"H₀": "Order‑0 Shannon entropy in bits per byte: −Σ p log₂ p over byte frequencies. Ignores order/context.",
		"≈ floor": "Rough lower bound on compressed size if you only knew byte frequencies: ceil(H₀ × bytes / 8).",
		sketch: "Byte length of the toy encoding shown above (not a real archive format).",
		Δ: "Change vs the source: negative means smaller, positive means larger.",
		cover: "UTF‑8 size of the visible cover text alone.",
		secret: "UTF‑8 size of the hidden secret.",
		overhead: "Extra bytes spent to hide the secret (stego cost).",
		recipe: "Byte length of the compact generator description.",
		ratio: "Expanded bytes ÷ recipe bytes — how much structure bought you.",
		out: "Byte length of the transformed output.",
		full: "Full data-URL byte length including prefix and base64.",
		inner: "Peeled payload byte length (what you should compress).",
	};

	const ERAS = [
		{
			title: "Codes before computers",
			body: "Morse and telegraph codes already shortened common letters. Shannon later formalized why: assign short codes to probable symbols. Compression starts as communication efficiency.",
			sample: "eeeeeeeeetttttaaaaa oooooooiiiiinnnnnssss",
			encode: (s) => {
				const freq = {};
				for (const ch of s.replace(/\s/g, "")) freq[ch] = (freq[ch] || 0) + 1;
				const ranked = Object.entries(freq).sort((a, b) => b[1] - a[1]);
				const codes = Object.fromEntries(ranked.map(([ch], i) => [ch, ".".repeat(i + 1)]));
				return (
					"MORSE-ISH map: " +
					ranked.map(([ch, n]) => `${ch}→${codes[ch]} (${n})`).join("  ") +
					"\n" +
					[...s].map((ch) => codes[ch] || ch).join(" ")
				);
			},
		},
		{
			title: "Huffman coding (1952)",
			body: "Build a prefix-free tree from symbol frequencies. Still the backbone of many codecs (including Deflate’s final stage). Pure entropy coding — no memory of previous matches.",
			sample: "banana bandana",
			encode: (s) => {
				const bytes = new TextEncoder().encode(s);
				const freq = new Map();
				for (const b of bytes) freq.set(b, (freq.get(b) || 0) + 1);
				const ranked = [...freq.entries()].sort((a, b) => b[1] - a[1]);
				const width = Math.max(1, Math.ceil(Math.log2(ranked.length + 1)));
				const bits = Object.fromEntries(
					ranked.map(([b], i) => [b, i.toString(2).padStart(width, "0")])
				);
				const stream = [...bytes].map((b) => bits[b]).join(" ");
				return `symbol→code: ${ranked
					.map(([b, n]) => `${JSON.stringify(String.fromCharCode(b))}→${bits[b]}×${n}`)
					.join("  ")}\n${stream}`;
			},
		},
		{
			title: "LZ77 / LZ78",
			body: "Replace repeated phrases with pointers into a sliding window or dictionary. Suddenly “structure over time” matters. Most modern general-purpose compressors are LZ descendants.",
			sample: "abracadabra abracadabra",
			encode: (s) => lzSketch(s),
		},
		{
			title: "Deflate, zip, gzip",
			body: "LZ77 + Huffman became the internet’s default plumbing. Folders became archives. Ratio was “good enough”; compatibility won. Still the baseline every new tool races.",
			sample: '<div class="item"><div class="item"><div class="item">x</div></div></div>',
			encode: (s) =>
				`LZ then Huffman (sketch):\n${lzSketch(s)}\n≈ then shorter codes for frequent symbols / match tokens.`,
		},
		{
			title: "PPM, PAQ, and deep context",
			body: "Predict the next byte from long context, then arithmetic-code the surprise. Slow, strong — the lineage behind Hutter Prize / enwik8 contests and modern neural predictors.",
			sample: "the the then there therefore",
			encode: (s) => {
				const words = s.split(/\s+/).filter(Boolean);
				return words
					.map((w, i) => {
						const prev = words[i - 1] || "∅";
						const pred =
							prev === "the" && w.startsWith("the")
								? `(predict “the…” from “${prev}”)`
								: `(novel after “${prev}”)`;
						return `${w} ${pred}`;
					})
					.join("\n");
			},
		},
		{
			title: "zstd, brotli, 7‑Zip…",
			body: "Engineering era: speed × ratio trade-offs, content-aware tricks, solid archives, and format-specific preprocessors for web, XML, and executables.",
			sample: '{"a":1,"a":1,"a":1,"b":2,"b":2}',
			encode: (s) => `minified: ${minifySketch(s)}\ndict:\n${tokenDictLossless(s)}`,
		},
	];

	const ENTROPY_SAMPLES = {
		english:
			"Compression is the art of throwing away only the surprise you can predict. English repeats spelling, grammar, and topic.",
		repeat: () => "pack ".repeat(50).trim(),
		zeros: () => "\0".repeat(200),
		random: () => {
			const bytes = new Uint8Array(160);
			crypto.getRandomValues(bytes);
			return Array.from(bytes, (b) => String.fromCharCode(b)).join("");
		},
		html: `<!DOCTYPE html>
<html lang="en">
<head><title>Demo</title><link rel="stylesheet" href="app.css"></head>
<body>
  <header class="site-header"><h1 class="title">Hello</h1></header>
  <main class="content"><p class="lead">Hello again</p></main>
</body>
</html>`,
		htmlMin: `<!DOCTYPE html><html lang="en"><head><title>Demo</title><link rel="stylesheet" href="app.css"></head><body><header class="site-header"><h1 class="title">Hello</h1></header><main class="content"><p class="lead">Hello again</p></main></body></html>`,
		jsonPretty: `{
  "users": [
    { "id": 1, "name": "Ada", "role": "admin" },
    { "id": 2, "name": "Alan", "role": "admin" },
    { "id": 3, "name": "Grace", "role": "user" }
  ]
}`,
		jsonMin: `{"users":[{"id":1,"name":"Ada","role":"admin"},{"id":2,"name":"Alan","role":"admin"},{"id":3,"name":"Grace","role":"user"}]}`,
		js: `function greet(name) {
  const message = "Hello, " + name + "!";
  console.log(message);
  return message;
}
greet("Ada");
greet("Alan");
greet("Grace");`,
		css: `.card { margin: 0; padding: 1rem; color: #12263a; }
.card-title { margin: 0; padding: 0; color: #12263a; }
.card-body { margin: 0.5rem 0 0; padding: 0; color: #3a5168; }`,
		xml: `<?xml version="1.0"?>
<catalog>
  <book id="1"><title>On Entropy</title><author>Shannon</author></book>
  <book id="2"><title>On Entropy</title><author>Cover</author></book>
  <book id="3"><title>Algorithms</title><author>Knuth</author></book>
</catalog>`,
		sql: `SELECT id, name, role FROM users WHERE role = 'admin';
SELECT id, name, role FROM users WHERE role = 'admin';
SELECT id, name, role FROM users WHERE role = 'user';`,
		base64:
			"TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlzIHNpbmd1bGFyIHBhc3Npb24gZnJvbSBvdGhlciBhbmltYWxz",
		dna: "ATGCATGCATGCATGCGGGCCCAAATTTATGCATGCATGC",
		csv: "name,role,score\nAda,admin,99\nAlan,admin,95\nGrace,user,88\nAda,admin,99",
	};

	const ENTROPY_CHIPS = [
		["english", "English"],
		["repeat", "Heavy repeat"],
		["zeros", "Null bytes"],
		["random", "Random"],
		["html", "HTML"],
		["htmlMin", "HTML min"],
		["jsonPretty", "JSON pretty"],
		["jsonMin", "JSON min"],
		["js", "JavaScript"],
		["css", "CSS"],
		["xml", "XML"],
		["sql", "SQL"],
		["base64", "Base64"],
		["dna", "DNA-ish"],
		["csv", "CSV"],
	];

	const CLASSIC_SAMPLES = {
		runs: "AAAAAAAABBBBBBBCCCC hello hello hello world world world",
		html: `<ul>\n  <li class="item">One</li>\n  <li class="item">Two</li>\n  <li class="item">Two</li>\n</ul>`,
		logs: "[INFO] start\n[INFO] tick\n[INFO] tick\n[INFO] tick\n[INFO] done",
		code: "return return return value; value; value;",
		bitmap: "00000000111111110000000011111111",
	};

	const LANG_SAMPLES = {
		html: ENTROPY_SAMPLES.html,
		css: ENTROPY_SAMPLES.css,
		js: ENTROPY_SAMPLES.js,
		json: ENTROPY_SAMPLES.jsonPretty,
		xml: ENTROPY_SAMPLES.xml,
		sql: ENTROPY_SAMPLES.sql,
		md: `# Compression\n\n## Entropy\n\n- Shannon\n- Huffman\n\n## Entropy\n\n- Shannon\n- LZ77`,
		php: `<?php\nfunction greet($name) {\n  echo "Hello, " . $name;\n}\ngreet("Ada");\ngreet("Ada");\ngreet("Alan");\n`,
		svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">\n  <rect x="10" y="10" width="80" height="80" fill="#0f766e"/>\n  <rect x="10" y="10" width="40" height="40" fill="#14b8a6"/>\n  <rect x="10" y="10" width="20" height="20" fill="#12263a"/>\n</svg>`,
	};

	const LABS = [
		{
			id: "predict",
			label: "Better predictors",
			problem:
				"Almost all remaining lossless compression headroom is in P(next | context) — estimating the next byte from long, messy history. Weak models waste bits on predictable structure; strong models (PPM, PAQ, transformers, …) are slow, huge, or brittle across domains.",
			toy: "This toy only blanks a word the second time it appears. That is not prediction, not probabilistic, and not bit-exact.",
			solve:
				"Build or adapt a context model that assigns calibrated probabilities to the next byte (or token), codes with arithmetic/ANS, stays lossless, and beats strong baselines (zstd/brotli/PAQ-class) on a stated corpus without cheating on wall time or memory.",
			input: "the cat sat on the mat and the cat sat on the mat again",
			run: (s) => {
				const words = s.split(/(\s+)/);
				const seen = new Map();
				return words
					.map((w) => {
						if (/^\s+$/.test(w)) return w;
						const key = w.toLowerCase();
						const n = seen.get(key) || 0;
						seen.set(key, n + 1);
						return n >= 1 ? "·" : w;
					})
					.join("");
			},
		},
		{
			id: "skeleton",
			label: "Document skeleton",
			problem:
				"Markup-heavy text (HTML, wiki XML, JSON APIs) repeats grammar frames while only slots vary. Naïve LZ sees the frames late or fragmented. Separating a reusable document skeleton from variable slots can help — but only if boundaries are free (no per-character “mask” tax) and decode is exact.",
			toy: "This sketch peels text nodes into slots and dictionaries repeated tag frames. It does not learn a grammar, handle attributes/scripts, prove minimality, or emit a real codec bitstream.",
			solve:
				"Infer a compact, reusable skeleton (or schema) for a document family, encode only slot values + skeleton id, guarantee byte-exact round-trip, and show a net win vs compressing the raw document with a strong general codec.",
			input: `<article class="post">
  <h1>Entropy</h1>
  <p>Shannon, 1948.</p>
  <h1>Entropy</h1>
  <p>Huffman, 1952.</p>
</article>`,
			run: (s) => skeletonReuse(s),
		},
		{
			id: "peel",
			label: "Format peel",
			problem:
				"Containers (zip, PDF, base64 data URLs, MPQ, images-with-headers, …) wrap already-structured or already-compressed payloads. Compressing the wrapper as opaque bytes often loses, or spends bits re-encoding entropy that a format-aware peel could discard or recompress better.",
			toy: "Only understands a trivial data-URL + base64 wrapper. No sniffing of real archives, no nested peel, no safe recompress tournament.",
			solve:
				"Detect wrappers reliably, peel to semantic payloads, recompress (or pass through) each layer with the right tool, reassemble bit-exact or document a precise semantic equivalence, and beat “gzip the whole blob” on mixed corpora.",
			input: "Hello Hello Hello Hello",
			run: (s) => {
				const prefix = document.getElementById("lab-peel-prefix").value || "data:text/plain;base64,";
				const b64 = btoa(unescape(encodeURIComponent(s)));
				const full = prefix.endsWith(",") ? prefix + b64 : prefix + "," + b64;
				return `full data URL (${byteLength(full)} B):\n${full}\n\npeeled inner (${byteLength(s)} B):\n${s}\n\n(compress the inner; the wrapper is just transport)`;
			},
		},
		{
			id: "geometry",
			label: "Geometric recipe",
			problem:
				"Some “random-looking” streams are low-description-length objects: epicycles, IFS, procedural textures, PRNG seeds. General compressors treat them as noise (~8 bpc) unless they rediscover the generator. Recognition is hard; false positives destroy ratio or correctness.",
			toy: "Expands a hand-written recipe you already typed. It never searches an unknown file for a generator, never picks among models, never proves uniqueness.",
			solve:
				"From bytes alone, detect (or approximate) a compact generative model, store the recipe + residuals if needed, decode exactly (or within a stated metric), and win on corpora where structure is geometric/procedural rather than textual.",
			input: "walkers:3 period:17 phase:0 map:mod26",
			run: (s) => {
				const period = Number((s.match(/period:(\d+)/) || [])[1]) || 17;
				const walkers = Number((s.match(/walkers:(\d+)/) || [])[1]) || 3;
				const phase = Number((s.match(/phase:(\d+)/) || [])[1]) || 0;
				let out = "";
				for (let t = 0; t < 200; t++) {
					let v = 0;
					for (let w = 0; w < walkers; w++) v += (t * (w + 1) + phase) % period;
					out += String.fromCharCode(97 + (v % 26));
				}
				return `recipe: ${s.trim()}\nexpanded (${out.length} chars):\n${out}`;
			},
		},
		{
			id: "minify",
			label: "Semantic minify",
			problem:
				"Source and markup carry comments, indentation, and alternate spellings that are irrelevant to machine meaning but expensive in bytes. Blind minifiers are lossy for humans and sometimes for machines (ASI, significant whitespace, CSS specificity). Semantic, reversible “minify for wire” is still underspecified.",
			toy: "Strips // and /* */ and smashes whitespace. It can break JS, ignores strings/regex, and cannot restore the original — so it is not a compressor.",
			solve:
				"Define a reversible normalization (or a dual channel: canonical machine form + human delta) for one language family, prove round-trip or document the semantic contract, and measure wins on real repos vs gzip/zstd of the originals.",
			input: `// greet someone\nfunction greet(name) {\n  /* temp */\n  return "Hi " + name;\n}\n`,
			run: (s) =>
				s
					.replace(/\/\*[\s\S]*?\*\//g, "")
					.replace(/(^|[^:])\/\/.*$/gm, "$1")
					.replace(/\s+/g, " ")
					.trim(),
		},
		{
			id: "delta",
			label: "Delta / diff",
			problem:
				"Near-duplicate records (JSON rows, VM snapshots, backups, game saves) differ in a few fields. Storing each full object repeats shared structure. Generic binary diff helps, but schema-aware deltas and ordered histories are still ad hoc across formats.",
			toy: "Shallow key diff of two one-line JSON objects. No arrays, nesting, moves, types, or streaming history; no codec framing.",
			solve:
				"Design a delta format for a chosen data model (e.g. JSON, tables, filesystems) that is compact, composable, and exactly reconstructs version N from base + patches — then beat storing N independent compressed snapshots.",
			input: `{"id":1,"name":"Ada","role":"admin","score":99}
{"id":1,"name":"Ada","role":"admin","score":100}`,
			run: (s) => {
				const lines = s.trim().split(/\n+/);
				if (lines.length < 2) return "Need two lines to diff.";
				try {
					const a = JSON.parse(lines[0]);
					const b = JSON.parse(lines[1]);
					const delta = {};
					const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
					for (const k of keys) {
						if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) delta[k] = b[k];
					}
					return `base: ${lines[0]}\ndelta: ${JSON.stringify(delta)}\n(rebuild = base ⊕ delta)`;
				} catch {
					return "Could not parse JSON lines.";
				}
			},
		},
	];

	function sampleValue(bag, key) {
		const v = bag[key];
		return typeof v === "function" ? v() : v;
	}

	function utf8Bytes(str) {
		return new TextEncoder().encode(str);
	}

	function byteLength(str) {
		return utf8Bytes(str).length;
	}

	function shannonBpc(str) {
		const bytes = utf8Bytes(str);
		if (!bytes.length) return 0;
		const freq = new Map();
		for (const b of bytes) freq.set(b, (freq.get(b) || 0) + 1);
		let h = 0;
		const n = bytes.length;
		for (const c of freq.values()) {
			const p = c / n;
			h -= p * Math.log2(p);
		}
		return h;
	}

	function formatBytes(n) {
		if (n < 1024) return `${n} B`;
		if (n < 1024 * 1024) return `${(n / 1024).toFixed(2)} KiB`;
		return `${(n / (1024 * 1024)).toFixed(2)} MiB`;
	}

	function formatDelta(from, to) {
		const d = to - from;
		const sign = d > 0 ? "+" : "";
		return `${sign}${d} B`;
	}

	function tipFor(label) {
		return METER_TIPS[label] || extraTip(label) || label;
	}

	function extraTip(label) {
		if (label.startsWith("«")) return "Dictionary token marker in the lossless body.";
		return "";
	}

	function metersHtml(items) {
		return items
			.map(([label, value, tone]) => {
				const cls = tone ? `meter meter--${tone}` : "meter";
				const tip = tipFor(label).replace(/"/g, "&quot;");
				return `<span class="${cls}" tabindex="0" title="${tip}" data-tip="${tip}">${label} <strong>${value}</strong></span>`;
			})
			.join("");
	}

	function renderMeters(el, str, extra = []) {
		if (!el) return;
		const bytes = byteLength(str);
		const bpc = shannonBpc(str);
		const floor = Math.ceil((bpc * bytes) / 8);
		const base = [
			["chars", String(str.length)],
			["bytes", formatBytes(bytes), "cool"],
			["H₀", `${bpc.toFixed(3)} bpc`],
			["≈ floor", formatBytes(floor), bpc < 4 ? "cool" : "hot"],
		];
		el.innerHTML = metersHtml(base.concat(extra));
	}

	function rleEncode(str) {
		if (!str) return "";
		let out = "";
		let i = 0;
		while (i < str.length) {
			const ch = str[i];
			let j = i + 1;
			while (j < str.length && str[j] === ch && j - i < 99) j++;
			const run = j - i;
			out += run > 3 ? `${ch}×${run}` : ch.repeat(run);
			i = j;
		}
		return out;
	}

	function dictEncode(str) {
		const tokens = str.match(/\S+|\s+/g) || [];
		const counts = new Map();
		for (const t of tokens) {
			if (/^\s+$/.test(t)) continue;
			counts.set(t, (counts.get(t) || 0) + 1);
		}
		const dict = [...counts.entries()]
			.filter(([w, c]) => w.length >= 2 && c >= 2)
			.sort((a, b) => b[1] * b[0].length - a[1] * a[0].length)
			.slice(0, 16)
			.map(([w], i) => [w, `#${i}`]);
		if (!dict.length) return str;
		const map = new Map(dict);
		const body = tokens.map((t) => map.get(t) || t).join("");
		const header = dict.map(([w, code]) => `${code}=${w}`).join(";");
		return `DICT[${header}]\n${body}`;
	}

	function lzSketch(str) {
		const minLen = 3;
		let i = 0;
		let out = "";
		while (i < str.length) {
			let best = null;
			const maxDist = Math.min(i, 64);
			for (let dist = 1; dist <= maxDist; dist++) {
				let len = 0;
				while (len < 32 && i + len < str.length && str[i - dist + len] === str[i + len]) len++;
				if (len >= minLen && (!best || len > best.len)) best = { dist, len };
			}
			if (best) {
				out += `<${best.dist},${best.len}>`;
				i += best.len;
			} else {
				out += str[i] === "<" ? "\\<" : str[i];
				i++;
			}
		}
		return out;
	}

	function wsCollapse(str) {
		return str.replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, "\n").trim();
	}

	function minifySketch(str) {
		return str
			.replace(/<!--[\s\S]*?-->/g, "")
			.replace(/\/\*[\s\S]*?\*\//g, "")
			.replace(/(^|[^:])\/\/.*$/gm, "$1")
			.replace(/>\s+</g, "><")
			.replace(/\s+/g, " ")
			.trim();
	}

	/** Longest repeated phrases (spaces included), lossless via «n» + JSON table. */
	function tokenDictLossless(str) {
		if (!str) return "";
		const n = str.length;
		const maxLen = Math.min(64, Math.floor(n / 2));
		const minLen = 2;
		const candidates = [];

		for (let len = maxLen; len >= minLen; len--) {
			const pos = new Map();
			for (let i = 0; i <= n - len; i++) {
				const sub = str.slice(i, i + len);
				if (sub.includes("«") || sub.includes("»")) continue;
				if (!pos.has(sub)) pos.set(sub, []);
				pos.get(sub).push(i);
			}
			for (const [sub, idxs] of pos) {
				let count = 0;
				let lastEnd = -1;
				for (const i of idxs) {
					if (i >= lastEnd) {
						count++;
						lastEnd = i + len;
					}
				}
				if (count < 2) continue;
				// Keep educational matches even when the toy header is larger than the savings.
				const net = len * count - 3 * count - (len + 8);
				candidates.push({ sub, len, count, savings: len * count, net });
			}
		}

		candidates.sort((a, b) => b.len - a.len || b.count - a.count || b.net - a.net);

		const dict = [];
		let body = str;
		for (const c of candidates) {
			if (dict.length >= 16) break;
			if (!body.includes(c.sub)) continue;
			// Prefer longer phrases; skip if this string is only inside an already-chosen longer token value
			if (dict.some(([, v]) => v.includes(c.sub) && v.length > c.sub.length)) continue;
			const code = `«${dict.length}»`;
			const parts = body.split(c.sub);
			if (parts.length < 2) continue;
			dict.push([code, c.sub]);
			body = parts.join(code);
		}

		if (!dict.length) {
			return `${str}\n\n(no repeated phrase ≥2 chars worth encoding — try HTML/JSON samples)`;
		}

		const header = dict.map(([code, s]) => `${code}=${JSON.stringify(s)}`).join("\n");
		const rebuilt = dict.reduceRight((acc, [code, s]) => acc.split(code).join(s), body);
		const ok = rebuilt === str ? "round-trip OK" : "round-trip FAILED";
		return `DICT (${ok} — expand «n» from JSON strings, spaces kept)\n${header}\n---\n${body}`;
	}

	function skeletonReuse(s) {
		const slots = [];
		const slotOf = new Map();
		let skeleton = s.replace(/>([^<]*)</g, (full, text) => {
			if (!/[^\s]/.test(text)) return full;
			const key = text;
			if (!slotOf.has(key)) {
				slotOf.set(key, slots.length);
				slots.push(text);
			}
			return `>{{${slotOf.get(key)}}}<`;
		});

		// Reuse repeated structural frames in the skeleton (longest first)
		const frames = tokenDictLossless(skeleton);
		const reusedSlots = slots.map((t, i) => `${i}: ${JSON.stringify(t)}`).join("\n");
		if (frames.startsWith("DICT")) {
			return `SLOTS (identical text shares an id):\n${reusedSlots}\n\n${frames}`;
		}
		return `SKELETON:\n${skeleton}\n\nSLOTS (identical text shares an id):\n${reusedSlots}`;
	}

	const ZW0 = "\u200B";
	const ZW1 = "\u200C";
	const DIGIT_LOOK = {
		0: "𝟶",
		1: "𝟷",
		2: "𝟸",
		3: "𝟹",
		4: "𝟺",
		5: "𝟻",
		6: "𝟼",
		7: "𝟽",
		8: "𝟾",
		9: "𝟿",
	};
	const DIGIT_LOOK_REV = Object.fromEntries(Object.entries(DIGIT_LOOK).map(([a, b]) => [b, a]));

	function stegoEmbed(cover, secret, mode) {
		if (mode === "zw") {
			const bits = Array.from(utf8Bytes(secret))
				.map((b) => b.toString(2).padStart(8, "0"))
				.join("");
			const payload = Array.from(bits, (bit) => (bit === "1" ? ZW1 : ZW0)).join("");
			const mid = Math.min(Math.floor(cover.length / 2), cover.length);
			return cover.slice(0, mid) + payload + cover.slice(mid);
		}
		if (mode === "trail") {
			const bits = Array.from(utf8Bytes(secret))
				.map((b) => b.toString(2).padStart(8, "0"))
				.join("");
			const lines = cover.split("\n");
			const out = [];
			let bi = 0;
			for (let i = 0; i < Math.max(lines.length, bits.length); i++) {
				const line = (lines[i] || "").replace(/[ \t]+$/g, "");
				const bit = bits[bi++];
				out.push(bit === undefined ? line : line + (bit === "1" ? " " : ""));
			}
			return out.join("\n");
		}
		if (mode === "html") {
			const b64 = btoa(unescape(encodeURIComponent(secret)));
			return `${cover}\n<!-- stego:${b64} -->`;
		}
		if (mode === "homoglyph") {
			let si = 0;
			const secretChars = [...secret];
			return (
				[...cover]
					.map((ch) => {
						if (si < secretChars.length && /\d/.test(ch)) {
							const dig = secretChars[si++];
							return DIGIT_LOOK[dig] || dig;
						}
						return ch;
					})
					.join("") + (si < secretChars.length ? ` [${secret.slice(si)}]` : "")
			);
		}
		return cover;
	}

	function stegoExtract(text, mode) {
		if (mode === "zw") {
			const bits = [];
			for (const ch of text) {
				if (ch === ZW0) bits.push("0");
				else if (ch === ZW1) bits.push("1");
			}
			return bitsToText(bits);
		}
		if (mode === "trail") {
			const bits = text.split("\n").map((line) => (/ $/.test(line) ? "1" : "0"));
			return bitsToText(bits);
		}
		if (mode === "html") {
			const m = text.match(/<!--\s*stego:([A-Za-z0-9+/=]+)\s*-->/);
			if (!m) return "";
			try {
				return decodeURIComponent(escape(atob(m[1])));
			} catch {
				return "";
			}
		}
		if (mode === "homoglyph") {
			return [...text].map((ch) => DIGIT_LOOK_REV[ch]).filter(Boolean).join("");
		}
		return "";
	}

	function bitsToText(bits) {
		if (!bits.length) return "";
		const bytes = [];
		for (let i = 0; i + 8 <= bits.length; i += 8) {
			bytes.push(parseInt(bits.slice(i, i + 8).join(""), 2));
		}
		try {
			return new TextDecoder().decode(Uint8Array.from(bytes));
		} catch {
			return "";
		}
	}

	function fillChips(el, items, { onSelect, onLoadSample, activeKey, loadTitle } = {}) {
		el.innerHTML = "";
		items.forEach(([key, label]) => {
			const b = document.createElement("button");
			b.type = "button";
			b.className = "chip" + (key === activeKey ? " is-on" : "");
			b.textContent = label;
			b.title = loadTitle || (onLoadSample ? "Double-click to load sample — single click never clears the text box" : "");
			b.addEventListener("click", () => {
				el.querySelectorAll(".chip").forEach((c) => c.classList.remove("is-on"));
				b.classList.add("is-on");
				if (onSelect) onSelect(key, b);
			});
			if (onLoadSample) {
				b.addEventListener("dblclick", (e) => {
					e.preventDefault();
					onLoadSample(key, b);
				});
			}
			el.appendChild(b);
		});
	}

	function wrapGo(delta) {
		const n = slides.length;
		go(((index + delta) % n + n) % n);
	}

	function go(i) {
		index = ((i % slides.length) + slides.length) % slides.length;
		slides.forEach((s, n) => {
			const on = n === index;
			s.hidden = !on;
			s.classList.toggle("is-active", on);
		});
		dotsEl.querySelectorAll("button").forEach((d, n) => {
			if (n === index) d.setAttribute("aria-current", "true");
			else d.removeAttribute("aria-current");
		});
		posEl.textContent = `${index + 1} / ${slides.length}`;
		history.replaceState(null, "", `#${index}`);
		if (index === 6) refreshStructMeters();
		if (index === 7) updateLab();
	}

	function readHash() {
		const n = Number((location.hash || "#0").slice(1));
		return Number.isFinite(n) ? n : 0;
	}

	function initDots() {
		slides.forEach((_, n) => {
			const b = document.createElement("button");
			b.type = "button";
			b.title = `Slide ${n + 1}`;
			b.addEventListener("click", () => go(n));
			dotsEl.appendChild(b);
		});
	}

	function showEra(i) {
		eraIndex = i;
		document.querySelectorAll(".era").forEach((el, n) => el.classList.toggle("is-on", n === i));
		const era = ERAS[i];
		document.getElementById("era-card").innerHTML = `<h3>${era.title}</h3><p>${era.body}</p>`;
		updateEra();
	}

	function updateEra() {
		const src = document.getElementById("era-in").value;
		const out = ERAS[eraIndex].encode(src);
		document.getElementById("era-out").value = out;
		renderMeters(document.getElementById("era-meters"), src, [
			["sketch", formatBytes(byteLength(out)), "cool"],
			["Δ", formatDelta(byteLength(src), byteLength(out)), byteLength(out) < byteLength(src) ? "cool" : "hot"],
		]);
	}

	function updateEntropy() {
		renderMeters(document.getElementById("entropy-meters"), document.getElementById("entropy-in").value);
	}

	function updateClassic() {
		const src = document.getElementById("classic-in").value;
		const rle = rleEncode(src);
		const dict = dictEncode(src);
		const lz = lzSketch(src);
		const ws = wsCollapse(src);
		document.getElementById("classic-rle").value = rle;
		document.getElementById("classic-dict").value = dict;
		document.getElementById("classic-lz").value = lz;
		document.getElementById("classic-ws").value = ws;
		const srcB = byteLength(src);
		renderMeters(document.getElementById("classic-src-meters"), src);
		[
			["classic-rle-meters", rle],
			["classic-dict-meters", dict],
			["classic-lz-meters", lz],
			["classic-ws-meters", ws],
		].forEach(([id, text]) => {
			renderMeters(document.getElementById(id), text, [
				["Δ", formatDelta(srcB, byteLength(text)), byteLength(text) < srcB ? "cool" : "hot"],
			]);
		});
	}

	function updateLang() {
		const src = document.getElementById("lang-in").value;
		const min = minifySketch(src);
		const tok = tokenDictLossless(src);
		document.getElementById("lang-min").value = min;
		document.getElementById("lang-tokens").value = tok;
		const srcB = byteLength(src);
		renderMeters(document.getElementById("lang-meters"), src);
		renderMeters(document.getElementById("lang-min-meters"), min, [
			["Δ", formatDelta(srcB, byteLength(min)), byteLength(min) < srcB ? "cool" : "hot"],
		]);
		renderMeters(document.getElementById("lang-tok-meters"), tok, [
			["Δ", formatDelta(srcB, byteLength(tok)), byteLength(tok) < srcB ? "cool" : "hot"],
		]);
	}

	function updateStego() {
		const cover = document.getElementById("stego-cover").value;
		const secret = document.getElementById("stego-secret").value;
		const out = stegoEmbed(cover, secret, stegoMode);
		document.getElementById("stego-out").value = out;
		renderMeters(document.getElementById("stego-meters"), out, [
			["cover", formatBytes(byteLength(cover))],
			["secret", formatBytes(byteLength(secret))],
			["overhead", formatDelta(byteLength(cover), byteLength(out)), "hot"],
		]);
		const revealed = stegoExtract(out, stegoMode);
		const box = document.getElementById("stego-reveal");
		box.textContent = revealed
			? `Extracted: ${JSON.stringify(revealed)}`
			: "No payload found for this mode (try a longer cover for trailing-spaces bits).";
	}

	function renderStructControls() {
		const host = document.getElementById("struct-controls");
		host.innerHTML = "";
		if (structTab === "ab") {
			const st = structState.ab;
			host.innerHTML = `
				<label>Block A <input type="range" data-k="a" min="2" max="24" value="${st.a}"/> <span>${st.a}</span></label>
				<label>Block B <input type="range" data-k="b" min="2" max="24" value="${st.b}"/> <span>${st.b}</span></label>
				<label>Repeats <input type="range" data-k="n" min="4" max="120" value="${st.n}"/> <span>${st.n}</span></label>`;
		} else if (structTab === "tag") {
			const st = structState.tag;
			host.innerHTML = `
				<label>Tag unit <input type="text" data-k="tag" class="live-input" value="${st.tag.replace(/"/g, "&quot;")}"/></label>
				<label>Repeats <input type="range" data-k="n" min="2" max="200" value="${st.n}"/> <span>${st.n}</span></label>`;
		} else {
			const st = structState.wave;
			host.innerHTML = `
				<label>Amplitude <input type="range" data-k="amp" min="1" max="9" value="${st.amp}"/> <span>${st.amp}</span></label>
				<label>Period <input type="range" data-k="period" min="2" max="24" value="${st.period}"/> <span>${st.period}</span></label>
				<label>Length <input type="range" data-k="len" min="40" max="400" value="${st.len}"/> <span>${st.len}</span></label>`;
		}
		host.querySelectorAll("input").forEach((inp) => {
			inp.addEventListener("input", () => {
				const k = inp.dataset.k;
				if (structTab === "tag" && k === "tag") structState.tag.tag = inp.value;
				else {
					const v = Number(inp.value);
					structState[structTab][k] = v;
					const span = inp.parentElement.querySelector("span");
					if (span) span.textContent = String(v);
				}
				updateStruct({ fromSliders: true });
			});
		});
	}

	function computeStruct() {
		if (structTab === "ab") {
			const { a, b, n } = structState.ab;
			return {
				expanded: ("a".repeat(a) + "b".repeat(b)).repeat(n),
				mark: `recipe: repeat(${n}, "a"*${a} + "b"*${b})`,
			};
		}
		if (structTab === "tag") {
			const { tag, n } = structState.tag;
			return {
				expanded: tag.repeat(n),
				mark: `recipe: repeat(${n}, ${JSON.stringify(tag)})`,
			};
		}
		const { amp, period, len, base } = structState.wave;
		let expanded = "";
		for (let i = 0; i < len; i++) {
			expanded += String(Math.floor(base + amp * Math.sin(i / period)));
		}
		return {
			expanded,
			mark: `recipe: digit = floor(${base}+${amp}*sin(i/${period})) for i in 0..${len - 1}`,
		};
	}

	function refreshStructMeters() {
		const expanded = document.getElementById("fractal-in").value;
		const mark = document.getElementById("fractal-mark").value;
		renderMeters(document.getElementById("fractal-meters"), expanded, [
			["recipe", formatBytes(byteLength(mark)), "cool"],
			["ratio", `${(byteLength(expanded) / Math.max(1, byteLength(mark))).toFixed(1)}×`, "cool"],
		]);
	}

	function updateStruct({ fromSliders = false } = {}) {
		const computed = computeStruct();
		if (fromSliders || !structDrafts[structTab]) {
			document.getElementById("fractal-in").value = computed.expanded;
			document.getElementById("fractal-mark").value = computed.mark;
			structDrafts[structTab] = { expanded: computed.expanded, mark: computed.mark };
		} else {
			const d = structDrafts[structTab];
			document.getElementById("fractal-in").value = d.expanded;
			document.getElementById("fractal-mark").value = d.mark;
		}
		refreshStructMeters();
	}

	function saveStructDraft() {
		structDrafts[structTab] = {
			expanded: document.getElementById("fractal-in").value,
			mark: document.getElementById("fractal-mark").value,
		};
	}

	function setStructTab(key, btn) {
		saveStructDraft();
		structTab = key;
		document.querySelectorAll("#struct-chips .chip").forEach((c) => c.classList.remove("is-on"));
		if (btn) btn.classList.add("is-on");
		renderStructControls();
		updateStruct({ fromSliders: false });
	}

	function setLab(id) {
		const inp = document.getElementById("lab-in");
		const prefixEl = document.getElementById("lab-peel-prefix");
		if (id !== labId) {
			labDrafts[labId] = inp.value;
			peelPrefixDrafts[labId] = prefixEl.value;
		}
		labId = id;
		document.querySelectorAll(".lab-tab").forEach((t) => {
			t.classList.toggle("is-on", t.dataset.lab === id);
			t.setAttribute("aria-selected", t.dataset.lab === id ? "true" : "false");
		});
		const lab = LABS.find((l) => l.id === id);
		document.getElementById("lab-desc").innerHTML = `
			<p class="lab-block"><span class="lab-kicker">Problem</span> ${lab.problem}</p>
			<p class="lab-block"><span class="lab-kicker lab-kicker--warn">Why this toy fails</span> ${lab.toy}</p>
			<p class="lab-block"><span class="lab-kicker lab-kicker--ok">What “solved” looks like</span> ${lab.solve}</p>`;
		const peelExtra = document.getElementById("lab-peel-extra");
		const isPeel = id === "peel";
		peelExtra.hidden = !isPeel;
		document.getElementById("lab-in-label").textContent = isPeel ? "Payload (plain text, editable)" : "Input";
		if (!(id in labDrafts)) labDrafts[id] = lab.input;
		inp.value = labDrafts[id];
		if (id in peelPrefixDrafts) prefixEl.value = peelPrefixDrafts[id];
		updateLab();
	}
	function updateLab() {
		const lab = LABS.find((l) => l.id === labId) || LABS[0];
		const src = document.getElementById("lab-in").value;
		const out = lab.run(src);
		document.getElementById("lab-out").value = out;
		const extras = [
			["out", formatBytes(byteLength(out)), "cool"],
			["Δ", formatDelta(byteLength(src), byteLength(out)), byteLength(out) < byteLength(src) ? "cool" : "hot"],
		];
		if (labId === "peel") {
			const prefix = document.getElementById("lab-peel-prefix").value || "";
			const b64 = btoa(unescape(encodeURIComponent(src)));
			const full = prefix.endsWith(",") ? prefix + b64 : prefix + "," + b64;
			extras.push(["full", formatBytes(byteLength(full)), "hot"]);
			extras.push(["inner", formatBytes(byteLength(src)), "cool"]);
		}
		renderMeters(document.getElementById("lab-meters"), src, extras);
	}

	function bind() {
		document.getElementById("prev").addEventListener("click", () => wrapGo(-1));
		document.getElementById("next").addEventListener("click", () => wrapGo(1));
		document.querySelectorAll("[data-goto]").forEach((el) => {
			el.addEventListener("click", () => go(Number(el.dataset.goto)));
		});

		document.querySelectorAll(".era").forEach((el) => {
			el.addEventListener("click", () => showEra(Number(el.dataset.era)));
		});
		document.getElementById("era-in").addEventListener("input", updateEra);

		document.getElementById("entropy-in").addEventListener("input", updateEntropy);
		fillChips(document.getElementById("entropy-chips"), ENTROPY_CHIPS, {
			onSelect: () => {},
			onLoadSample: (key) => {
				document.getElementById("entropy-in").value = sampleValue(ENTROPY_SAMPLES, key);
				updateEntropy();
			},
		});

		document.getElementById("classic-in").addEventListener("input", updateClassic);
		fillChips(
			document.getElementById("classic-chips"),
			Object.keys(CLASSIC_SAMPLES).map((k) => [k, k]),
			{
				onSelect: () => {},
				onLoadSample: (key) => {
					document.getElementById("classic-in").value = CLASSIC_SAMPLES[key];
					updateClassic();
				},
			}
		);

		fillChips(
			document.getElementById("lang-chips"),
			Object.keys(LANG_SAMPLES).map((k) => [k, k.toUpperCase()]),
			{
				activeKey: "html",
				onSelect: () => {},
				onLoadSample: (key) => {
					document.getElementById("lang-in").value = LANG_SAMPLES[key];
					updateLang();
				},
			}
		);
		if (!document.getElementById("lang-in").value) {
			document.getElementById("lang-in").value = LANG_SAMPLES.html;
		}
		document.getElementById("lang-in").addEventListener("input", updateLang);

		document.querySelectorAll("[data-stego-mode]").forEach((btn) => {
			btn.addEventListener("click", () => {
				stegoMode = btn.dataset.stegoMode;
				document.querySelectorAll("[data-stego-mode]").forEach((b) => b.classList.toggle("is-on", b === btn));
				updateStego();
			});
		});
		["stego-cover", "stego-secret"].forEach((id) => {
			document.getElementById(id).addEventListener("input", updateStego);
		});

		fillChips(
			document.getElementById("struct-chips"),
			[
				["ab", "A/B blocks"],
				["tag", "Tag chorus"],
				["wave", "Sine digits"],
			],
			{
				activeKey: "ab",
				onSelect: (key, btn) => setStructTab(key, btn),
			}
		);
		document.getElementById("fractal-in").addEventListener("input", () => {
			saveStructDraft();
			refreshStructMeters();
		});

		const tabs = document.getElementById("lab-tabs");
		LABS.forEach((lab) => {
			const b = document.createElement("button");
			b.type = "button";
			b.className = "lab-tab chip";
			b.dataset.lab = lab.id;
			b.setAttribute("role", "tab");
			b.textContent = lab.label;
			b.addEventListener("click", () => setLab(lab.id));
			tabs.appendChild(b);
		});
		document.getElementById("lab-in").addEventListener("input", () => {
			labDrafts[labId] = document.getElementById("lab-in").value;
			updateLab();
		});
		document.getElementById("lab-peel-prefix").addEventListener("input", () => {
			peelPrefixDrafts[labId] = document.getElementById("lab-peel-prefix").value;
			updateLab();
		});

		window.addEventListener("keydown", (e) => {
			const tag = (e.target && e.target.tagName) || "";
			if (tag === "TEXTAREA" || tag === "INPUT") {
				if (e.key === "Escape") e.target.blur();
				return;
			}
			if (e.key === "ArrowRight" || e.key === " " || e.key === "PageDown") {
				e.preventDefault();
				wrapGo(1);
			} else if (e.key === "ArrowLeft" || e.key === "PageUp") {
				e.preventDefault();
				wrapGo(-1);
			} else if (e.key === "Home" || e.key === "0") go(0);
			else if (e.key === "End") go(slides.length - 1);
			else if (/^[1-8]$/.test(e.key)) go(Number(e.key) - 1);
		});
		window.addEventListener("hashchange", () => go(readHash()));
	}

	initDots();
	bind();
	document.getElementById("era-in").value = ERAS[0].sample;
	showEra(0);
	updateEntropy();
	updateClassic();
	updateLang();
	updateStego();
	renderStructControls();
	updateStruct({ fromSliders: true });
	setLab("predict");
	go(readHash());
	deck.focus({ preventScroll: true });
})();
