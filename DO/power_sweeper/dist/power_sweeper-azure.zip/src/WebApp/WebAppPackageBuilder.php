<?php

declare(strict_types=1);

namespace PowerSweeper\WebApp;

require_once dirname(__DIR__, 2) . '/templates/web_package/php/MailAllowlist.php';

/**
 * Build a self-contained web package (PHP or Python × LOM or SQL) from the conversion file.
 */
final class WebAppPackageBuilder
{
    public function __construct(
        private readonly SweeperStyles $sweeper = new SweeperStyles(),
        private readonly WebAppPixelRenderer $renderer = new WebAppPixelRenderer(),
    ) {
    }

    /**
     * @param array<string, mixed> $ir
     * @return array{ok:bool, path?:string, message:string, used_sweeper?:bool, inline_styles?:int}
     */
    public function build(array $ir, string $outputZip, ?string $extractDir = null): array
    {
        $export = is_array($ir['export'] ?? null) ? $ir['export'] : [];
        $runtime = WebAppIrBuilder::normalizeRuntime((string) ($export['runtime'] ?? 'php'));
        $storage = WebAppIrBuilder::normalizeStorage((string) ($export['storage'] ?? 'lom'));
        $layout = WebAppIrBuilder::normalizeLayout((string) ($export['layout'] ?? 'pixel'));

        if ($layout === 'modern') {
            return [
                'ok' => false,
                'message' => 'layout=modern is reserved; use layout=pixel for this step',
            ];
        }

        $staging = sys_get_temp_dir() . '/ps_pkg_' . bin2hex(random_bytes(4));
        if (!mkdir($staging, 0775, true) && !is_dir($staging)) {
            return ['ok' => false, 'message' => 'failed to create staging dir'];
        }

        try {
            $this->writeTree($staging, $ir, $runtime, $storage, $extractDir);
            $intermediate = $this->renderer->renderIntermediate($ir);
            $converted = $this->sweeper->convert($intermediate);
            $html = $converted['html'];
            $inline = preg_match_all('/\sstyle="/i', $html) ?: 0;
            if ($inline > 0) {
                $forced = $this->sweeper->fallbackConvert($html);
                $html = $forced['html'];
                $inline = preg_match_all('/\sstyle="/i', $html) ?: 0;
            }

            $public = $staging . '/public';
            if (!is_dir($public)) {
                mkdir($public, 0775, true);
            }
            file_put_contents($public . '/index.html', $html);
            $this->copySharedAssets($public);
            $this->seedData($staging, $ir, $storage);

            $dir = dirname($outputZip);
            if (!is_dir($dir)) {
                mkdir($dir, 0775, true);
            }
            $this->zipDir($staging, $outputZip);

            // Also mirror into the .msapp WebApp/ folder when unpacking in-place.
            if ($extractDir !== null && $extractDir !== '' && is_dir($extractDir)) {
                $webDir = $extractDir . '/WebApp';
                if (!is_dir($webDir)) {
                    mkdir($webDir, 0775, true);
                }
                $pkgCopy = $webDir . '/package.zip';
                copy($outputZip, $pkgCopy);
                file_put_contents($webDir . '/package_meta.json', json_encode([
                    'runtime' => $runtime,
                    'storage' => $storage,
                    'layout' => $layout,
                    'generated_at' => gmdate('c'),
                ], JSON_PRETTY_PRINT) . "\n");
            }

            return [
                'ok' => true,
                'path' => $outputZip,
                'message' => sprintf(
                    'package %s/%s layout=%s (%d classes, inline=%d)',
                    $runtime,
                    $storage,
                    $layout,
                    (int) ($converted['class_count'] ?? 0),
                    $inline,
                ),
                'used_sweeper' => (bool) ($converted['used_sweeper'] ?? false),
                'inline_styles' => $inline,
            ];
        } finally {
            $this->rmTree($staging);
        }
    }

    /**
     * @param array<string, mixed> $ir
     */
    private function writeTree(string $staging, array $ir, string $runtime, string $storage, ?string $extractDir): void
    {
        foreach (['public/assets/media', 'ir', 'data', 'azure', 'server'] as $rel) {
            $path = $staging . '/' . $rel;
            if (!is_dir($path)) {
                mkdir($path, 0775, true);
            }
        }

        file_put_contents(
            $staging . '/ir/power_sweeper_ir.json',
            json_encode($ir, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n",
        );

        $templates = dirname(__DIR__, 2) . '/templates/web_package';
        $this->writeFile($staging . '/public/assets/app.css', (string) file_get_contents($templates . '/assets/app.css'));
        $this->writeFile($staging . '/public/assets/runtime.js', (string) file_get_contents($templates . '/assets/runtime.js'));
        $this->writeFile($staging . '/azure/startup.sh', (string) file_get_contents($templates . '/azure/startup.sh'));
        chmod($staging . '/azure/startup.sh', 0755);

        $config = [
            'runtime' => $runtime,
            'storage' => $storage,
            'layout' => 'pixel',
            'lom_home' => getenv('LOM_HOME') ?: '/srv/http/LOM',
            'sql_dsn' => getenv('SQL_DSN') ?: '',
            'mail_delivery' => getenv('MAIL_DELIVERY') ?: 'outbox',
            'mail_unlisted' => getenv('MAIL_UNLISTED') ?: 'rewrite',
            'mail_allowlist' => \MailAllowlist::defaultAddresses(),
        ];
        file_put_contents(
            $staging . '/server/config.json',
            json_encode($config, JSON_PRETTY_PRINT) . "\n",
        );

        if ($runtime === 'php') {
            $this->writeFile($staging . '/index.php', (string) file_get_contents($templates . '/php/index.php'));
            $this->writeFile($staging . '/router.php', (string) file_get_contents($templates . '/php/router.php'));
            $this->writeFile($staging . '/server/api.php', (string) file_get_contents($templates . '/php/api.php'));
            $this->writeFile($staging . '/server/LomStore.php', (string) file_get_contents($templates . '/php/LomStore.php'));
            $this->writeFile($staging . '/server/SqlStore.php', (string) file_get_contents($templates . '/php/SqlStore.php'));
            $this->writeFile($staging . '/server/TableMap.php', (string) file_get_contents($templates . '/php/TableMap.php'));
            $this->writeFile($staging . '/server/MailAllowlist.php', (string) file_get_contents($templates . '/php/MailAllowlist.php'));
            $this->writeFile($staging . '/server/MailGateway.php', (string) file_get_contents($templates . '/php/MailGateway.php'));
            $this->writeFile($staging . '/server/StoreSeed.php', (string) file_get_contents($templates . '/php/StoreSeed.php'));
        } else {
            $this->writeFile($staging . '/app.py', (string) file_get_contents($templates . '/python/app.py'));
            $this->writeFile($staging . '/server/store.py', (string) file_get_contents($templates . '/python/store.py'));
            $this->writeFile($staging . '/requirements.txt', "No external packages required for the bundled local SQL path.\n");
        }

        file_put_contents($staging . '/README.md', $this->readme($runtime, $storage));
        $this->copyMedia($staging, $ir, $extractDir);
    }

    /**
     * @param array<string, mixed> $ir
     */
    private function copyMedia(string $staging, array $ir, ?string $extractDir): void
    {
        if ($extractDir === null || $extractDir === '' || !is_dir($extractDir)) {
            return;
        }
        $dest = $staging . '/public/assets/media';
        if (!is_dir($dest)) {
            mkdir($dest, 0775, true);
        }
        foreach (is_array($ir['media'] ?? null) ? $ir['media'] : [] as $res) {
            if (!is_array($res)) {
                continue;
            }
            $rel = str_replace('\\', '/', (string) ($res['path'] ?? ''));
            $src = $extractDir . '/' . $rel;
            if (!is_file($src)) {
                $file = (string) ($res['file'] ?? '');
                $alt = $extractDir . '/Assets/Images/' . $file;
                $src = is_file($alt) ? $alt : '';
            }
            if ($src === '' || !is_file($src)) {
                continue;
            }
            $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION) ?: 'png');
            $safe = preg_replace('/[^\w.-]+/', '_', (string) ($res['name'] ?? 'media')) ?: 'media';
            copy($src, $dest . '/' . $safe . '.' . $ext);
        }
    }

    private function copySharedAssets(string $public): void
    {
        $assets = $public . '/assets';
        if (!is_dir($assets)) {
            mkdir($assets, 0775, true);
        }
    }

    /**
     * @param array<string, mixed> $ir
     */
    private function seedData(string $staging, array $ir, string $storage): void
    {
        $tables = is_array($ir['tables'] ?? null) ? $ir['tables'] : [];
        if ($storage === 'lom') {
            $xml = "<app>\n";
            foreach ($tables as $table) {
                if (!is_array($table)) {
                    continue;
                }
                $tName = htmlspecialchars((string) ($table['safe_name'] ?? $table['name'] ?? 'Items'), ENT_QUOTES);
                $xml .= "  <{$tName}>\n";
                foreach ($table['rows'] ?? [] as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $xml .= "    <row";
                    foreach ($row as $k => $v) {
                        $xml .= ' ' . preg_replace('/\W+/', '_', (string) $k)
                            . '="' . htmlspecialchars((string) $v, ENT_QUOTES) . '"';
                    }
                    $xml .= ">";
                    $title = (string) ($row['Title'] ?? $row['title'] ?? '');
                    $xml .= htmlspecialchars($title, ENT_QUOTES) . "</row>\n";
                }
                $xml .= "  </{$tName}>\n";
            }
            $xml .= "</app>\n";
            file_put_contents($staging . '/data/app.xml', $xml);
            return;
        }

        $schema = "-- Generated by Power Sweeper\n";
        foreach ($tables as $table) {
            if (!is_array($table)) {
                continue;
            }
            $tName = preg_replace('/\W+/', '_', (string) ($table['safe_name'] ?? $table['name'] ?? 'Items')) ?: 'Items';
            $cols = is_array($table['columns'] ?? null) ? $table['columns'] : ['Id', 'Title', 'Value'];
            $colDefs = [];
            $seenCols = [];
            $insertCols = [];
            foreach ($cols as $col) {
                $c = preg_replace('/\W+/', '_', (string) $col) ?: 'col';
                $key = strtolower($c);
                if (isset($seenCols[$key])) {
                    continue;
                }
                $seenCols[$key] = true;
                $insertCols[] = [$col, $c];
                $colDefs[] = $key === 'id' ? 'Id INTEGER PRIMARY KEY' : $c . ' TEXT';
            }
            $schema .= 'CREATE TABLE IF NOT EXISTS ' . $tName . ' (' . implode(', ', $colDefs) . ");\n";
            foreach ($table['rows'] ?? [] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $names = [];
                $vals = [];
                foreach ($insertCols as [$col, $c]) {
                    $names[] = $c;
                    $v = $row[$col] ?? $row[$c] ?? '';
                    $vals[] = "'" . str_replace("'", "''", (string) $v) . "'";
                }
                $schema .= 'INSERT INTO ' . $tName . ' (' . implode(', ', $names) . ') VALUES ('
                    . implode(', ', $vals) . ");\n";
            }
        }
        file_put_contents($staging . '/data/schema.sql', $schema);

        $dbPath = $staging . '/data/app.sqlite';
        if (class_exists(\PDO::class)) {
            try {
                $pdo = new \PDO('sqlite:' . $dbPath);
                $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                $pdo->exec($schema);
            } catch (\Throwable) {
                // schema.sql alone is enough for Python sqlite3 to apply on first boot
            }
        }
    }

    private function readme(string $runtime, string $storage): string
    {
        return "# Power Sweeper Web Package\n\n"
            . "Runtime: **{$runtime}**  \n"
            . "Storage: **{$storage}**  \n"
            . "Layout: **pixel**\n\n"
            . "## Drop onto a server\n\n"
            . "Unzip into the web root. Set the Azure startup command to:\n\n"
            . "```bash\nbash /home/site/wwwroot/azure/startup.sh\n```\n\n"
            . ($storage === 'lom'
                ? "Requires LOM at `/srv/http/LOM` (or set `LOM_HOME`).\n"
                : "Uses local SQL (`data/app.sqlite`). Set `SQL_DSN` for another SQL engine.\n");
    }

    private function writeFile(string $path, string $contents): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        file_put_contents($path, $contents);
    }

    private function zipDir(string $dir, string $zipPath): void
    {
        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Cannot create zip: ' . $zipPath);
        }
        $dir = realpath($dir) ?: $dir;
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
        );
        foreach ($it as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $full = $file->getPathname();
            $local = ltrim(str_replace($dir, '', $full), '/\\');
            $zip->addFile($full, str_replace('\\', '/', $local));
        }
        $zip->close();
    }

    private function rmTree(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($it as $file) {
            $path = $file->getPathname();
            if ($file->isDir()) {
                @rmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }
}
