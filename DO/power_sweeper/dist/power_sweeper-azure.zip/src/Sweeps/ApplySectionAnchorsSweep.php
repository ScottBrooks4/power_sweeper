<?php

declare(strict_types=1);

namespace PowerSweeper\Sweeps;

use PowerSweeper\ControlDocument;
use PowerSweeper\ControlNode;
use PowerSweeper\Report;

/**
 * Apply VCR-style mid-section SetFocus anchors into scrollable form sections.
 *
 * Power Apps scrolls with SetFocus on 1×1 Classic buttons whose Y is typically
 * `{ScrollParent}.Height / 2`. That places the marker mid-viewport so the
 * section header lands near the top — the same geometry the web package emits
 * as `<a id="AnchorN">` for hash / data-scroll-to convertability.
 *
 * VCR also keeps an `AnchorPark` reset target; Jump / tab formulas often do
 * `SetFocus(AnchorPark); SetFocus(AnchorN)`.
 */
final class ApplySectionAnchorsSweep implements SweepInterface
{
    public const PARK_NAME = 'AnchorPark';

    public static function id(): string
    {
        return 'apply_section_anchors';
    }

    public static function label(): string
    {
        return 'Apply section anchors';
    }

    public static function description(): string
    {
        return 'Insert 1×1 Classic SetFocus anchors into scrollable form sections (Y = ScrollParent.Height / 2) plus AnchorPark, matching the VCR pattern so Studio SetFocus and web <a id> scroll targets stay convertible.';
    }

    public function apply(array $documents, Report $report, array $options = []): void
    {
        $prefix = is_string($options['prefix'] ?? null) && trim((string) $options['prefix']) !== ''
            ? trim((string) $options['prefix'])
            : 'Anchor';
        $forceY = !array_key_exists('force_y', $options) || (bool) $options['force_y'];
        $park = !array_key_exists('anchor_park', $options) || (bool) $options['anchor_park'];
        $x = isset($options['x']) ? (string) $options['x'] : '40';

        foreach ($documents as $doc) {
            if ($doc->format !== 'yaml') {
                // YAML is the editable Studio surface; JSON ControlTree inserts are riskier.
                continue;
            }

            foreach ($doc->controls() as $scroll) {
                if (!$this->isScrollParent($scroll, $options)) {
                    continue;
                }
                $sections = $this->sectionChildren($scroll);
                $usedNames = [];
                $index = 1;
                foreach ($sections as $section) {
                    $anchorName = $this->preferredAnchorName($section, $prefix, $index, $usedNames);
                    $usedNames[strtolower($anchorName)] = true;
                    $existing = $this->findNamedChild($section, $anchorName)
                        ?? $this->findExistingAnchor($section, $prefix);
                    if ($existing !== null) {
                        if ($forceY) {
                            $this->ensureMidViewportY($existing, $scroll->name, $report);
                        }
                        $this->ensureAnchorChrome($existing, $report);
                        $index++;
                        continue;
                    }
                    $this->insertAnchor($section, $anchorName, $scroll->name, $x, $report, true);
                    $index++;
                }
                if ($park) {
                    $this->ensureAnchorPark($scroll, $x, $report);
                }
            }
        }
    }

    /**
     * @param array<string, mixed> $options
     */
    private function isScrollParent(ControlNode $control, array $options): bool
    {
        $nameHint = is_string($options['scroll_name'] ?? null) ? trim((string) $options['scroll_name']) : '';
        if ($nameHint !== '' && strcasecmp($control->name, $nameHint) === 0) {
            return true;
        }
        if (preg_match('/scrollable|scroll.?form|form.?scroll/i', $control->name) === 1) {
            return true;
        }
        if (!$control->isContainer()) {
            return false;
        }
        $dir = strtolower((string) ($control->getProperty('LayoutDirection') ?? ''));
        $overflow = strtolower((string) ($control->getProperty('LayoutOverflowY') ?? $control->getProperty('OverflowY') ?? ''));
        if (str_contains($dir, 'vertical') && (str_contains($overflow, 'scroll') || str_contains($overflow, 'auto'))) {
            return true;
        }

        return false;
    }

    /**
     * @return list<ControlNode>
     */
    private function sectionChildren(ControlNode $scroll): array
    {
        $out = [];
        foreach ($scroll->children as $child) {
            if (!$child instanceof ControlNode) {
                continue;
            }
            if ($this->looksLikeAnchor($child) || strcasecmp($child->name, self::PARK_NAME) === 0) {
                continue;
            }
            if (!$child->isContainer()) {
                continue;
            }
            // Skip parking pads, chrome rows, and non-section chrome.
            if (preg_match(
                '/^(AnchorPark|NavTabs|Sidebar|Topbar|Header|Footer)|Checkboxes?$|_Header$|HeaderAndSelect/i',
                $child->name
            ) === 1) {
                continue;
            }
            $out[] = $child;
        }

        // Prefer numbered / annex sections when present; otherwise keep container children.
        $named = array_values(array_filter(
            $out,
            fn(ControlNode $c): bool => $this->looksLikeSectionName($c->name)
        ));

        return $named !== [] ? $named : $out;
    }

    private function looksLikeSectionName(string $name): bool
    {
        return (bool) preg_match(
            '/^(\d+[_\s-]|Annex|Section|Destination|Organization|Summary|Sites|Visitors|Remarks|Pertinence|Initiative|Classification|Dates?|Security)/i',
            $name
        );
    }

    private function looksLikeAnchor(ControlNode $control): bool
    {
        if (preg_match('/^Anchor(Park|[A-Za-z].*|\d+)$/i', $control->name) === 1) {
            return true;
        }
        $w = $this->numericProp($control->getProperty('Width'));
        $h = $this->numericProp($control->getProperty('Height'));

        return $w !== null && $h !== null && $w <= 2 && $h <= 2
            && stripos($control->type, 'button') !== false;
    }

    /**
     * @param array<string, true> $usedNames
     */
    private function preferredAnchorName(ControlNode $section, string $prefix, int $index, array $usedNames): string
    {
        $n = strtolower($section->name);
        $candidates = [];
        if (str_contains($n, 'site') && !str_contains($n, 'visit')) {
            $candidates[] = $prefix === 'Anchor' ? 'AnchorSites' : $prefix . 'Sites';
        }
        if (str_contains($n, 'visitor')) {
            $candidates[] = $prefix === 'Anchor' ? 'AnchorVisitors' : $prefix . 'Visitors';
        }
        if (preg_match('/emergenc/i', $n) === 1) {
            $candidates[] = $prefix === 'Anchor' ? 'AnchorEmer' : $prefix . 'Emer';
        }
        // 1_Destination / 5_Summary_Contents → Anchor1 / Anchor5 (VCR / colFormSections style).
        if (preg_match('/^(\d+)/', $section->name, $m) === 1) {
            $candidates[] = $prefix . (int) $m[1];
        }
        $candidates[] = $prefix . $index;

        foreach ($candidates as $name) {
            if (!isset($usedNames[strtolower($name)])) {
                return $name;
            }
        }

        return $prefix . $index . '_' . substr(sha1($section->path), 0, 4);
    }

    private function findNamedChild(ControlNode $parent, string $name): ?ControlNode
    {
        foreach ($parent->children as $child) {
            if ($child instanceof ControlNode && strcasecmp($child->name, $name) === 0) {
                return $child;
            }
            if ($child instanceof ControlNode) {
                $nested = $this->findNamedChild($child, $name);
                if ($nested !== null) {
                    return $nested;
                }
            }
        }

        return null;
    }

    private function findExistingAnchor(ControlNode $section, string $prefix): ?ControlNode
    {
        foreach ($section->children as $child) {
            if (!$child instanceof ControlNode) {
                continue;
            }
            if (str_starts_with(strtolower($child->name), strtolower($prefix)) || $this->looksLikeAnchor($child)) {
                return $child;
            }
        }

        return null;
    }

    private function ensureAnchorPark(ControlNode $scroll, string $x, Report $report): void
    {
        $existing = $this->findNamedChild($scroll, self::PARK_NAME);
        if ($existing !== null) {
            $this->ensureAnchorChrome($existing, $report);
            return;
        }
        // Prefer nesting under an existing park container when present.
        foreach ($scroll->children as $child) {
            if ($child instanceof ControlNode && preg_match('/AnchorPark/i', $child->name) === 1 && $child->isContainer()) {
                if ($this->findNamedChild($child, self::PARK_NAME) === null) {
                    $this->insertAnchor($child, self::PARK_NAME, $scroll->name, $x, $report, false);
                }
                return;
            }
        }
        $this->insertAnchor($scroll, self::PARK_NAME, $scroll->name, $x, $report, false);
    }

    private function insertAnchor(
        ControlNode $section,
        string $anchorName,
        string $scrollName,
        string $x,
        Report $report,
        bool $midViewport,
    ): void {
        $safeScroll = $this->quoteIdent($scrollName);
        $y = $midViewport ? ('=' . $safeScroll . '.Height / 2') : '=15';
        $body = [
            'Control' => 'Classic/Button@2.2.0',
            'Properties' => [
                'X' => '=' . $x,
                'Y' => $y,
                'Width' => '=1',
                'Height' => '=1',
                'Text' => '="' . str_replace('"', '""', $anchorName) . '"',
                'Fill' => '=RGBA(0, 0, 0, 0)',
                'Color' => '=RGBA(0, 0, 0, 0)',
                'BorderThickness' => '=0',
                'BorderColor' => '=RGBA(0, 0, 0, 0)',
                'FocusedBorderThickness' => '=0',
                'TabIndex' => '=-1',
                'AccessibleLabel' => '="' . str_replace('"', '""', $anchorName) . ' scroll target"',
            ],
        ];
        $section->addYamlChild($anchorName, $body);
        $report->add(
            self::id(),
            $section->path . '/' . $anchorName,
            'Control',
            '(missing)',
            'Classic/Button 1×1 Y=' . ltrim($y, '=')
        );
    }

    private function ensureMidViewportY(ControlNode $anchor, string $scrollName, Report $report): void
    {
        if (strcasecmp($anchor->name, self::PARK_NAME) === 0) {
            return;
        }
        $safeScroll = $this->quoteIdent($scrollName);
        $want = '=' . $safeScroll . '.Height / 2';
        $from = $anchor->getProperty('Y');
        $compact = str_replace(' ', '', (string) $from);
        if ($from !== null && str_contains($compact, $safeScroll . '.Height/2')) {
            return;
        }
        if ($from !== null && str_contains((string) $from, $safeScroll) && str_contains((string) $from, 'Height')) {
            return;
        }
        $anchor->setProperty('Y', $want);
        $report->add(self::id(), $anchor->path, 'Y', $from ?? '(unset)', $want);
    }

    private function ensureAnchorChrome(ControlNode $anchor, Report $report): void
    {
        $targets = [
            'Width' => '=1',
            'Height' => '=1',
            'Fill' => '=RGBA(0, 0, 0, 0)',
            'TabIndex' => '=-1',
        ];
        foreach ($targets as $prop => $want) {
            $from = $anchor->getProperty($prop);
            $normFrom = str_replace(' ', '', ltrim((string) $from, '='));
            $normWant = str_replace(' ', '', ltrim($want, '='));
            if ($from !== null && strcasecmp($normFrom, $normWant) === 0) {
                continue;
            }
            // Don't fight formula Width/Height on park containers.
            if (($prop === 'Width' || $prop === 'Height') && $from !== null && !is_numeric(ltrim($from, '='))) {
                continue;
            }
            $anchor->setProperty($prop, $want);
            $report->add(self::id(), $anchor->path, $prop, $from ?? '(unset)', $want);
        }
    }

    private function quoteIdent(string $name): string
    {
        if (preg_match('/^[A-Za-z_][\w]*$/', $name) === 1) {
            return $name;
        }

        return "'" . str_replace("'", "''", $name) . "'";
    }

    private function numericProp(?string $raw): ?float
    {
        if ($raw === null) {
            return null;
        }
        $v = ltrim(trim($raw), '=');
        if (is_numeric($v)) {
            return (float) $v;
        }

        return null;
    }
}
