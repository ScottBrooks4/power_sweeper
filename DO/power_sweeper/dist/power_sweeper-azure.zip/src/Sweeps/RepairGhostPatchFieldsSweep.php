<?php

declare(strict_types=1);

namespace PowerSweeper\Sweeps;

use PowerSweeper\AppControlCatalog;
use PowerSweeper\AppDataContext;
use PowerSweeper\PowerFxFormulaSegments;
use PowerSweeper\Report;

/**
 * Remove Patch record fields in live code that reference controls which do not exist
 * anywhere in the app (legacy copy-paste from duplicated screens).
 *
 * Ghosts are discovered heuristically from `Field: Field.Prop` record lines whose
 * control is absent from the catalog; a small seed list covers known VCR leftovers.
 * Comment regions are never read or modified.
 */
final class RepairGhostPatchFieldsSweep implements SweepInterface
{
    /**
     * Seed names commonly left behind after VCR screen duplication.
     * Discovery adds any other `Name: Name[.Prop]` lines whose Name is absent.
     *
     * @var list<string>
     */
    private const GHOST_SEEDS = [
        'OneTimeVisit',
        'RecurringVisit',
        'EmergencyVisit',
        'AmendmentVisit',
        'GovernmentInitiave',
        'CommercialInitiave',
        'InitiatedByRequestingAgency',
        'ByInvitationOfFacility',
        'PertinentToEquipment',
        'PertinentToSales',
        'PertinentToProgramme',
        'PertinentToDefense',
        'PertinentToDefence',
        'PertinentToOther',
        'LevelUnclassified',
        'LevelRestricted',
        'LevelConfidential',
        'LevelSecret',
        'LevelTopSecret',
        'LevelOther',
        'LevelSpecify',
        'Subject',
        'EmerContactPostal',
        'EmerContactTelArea',
        'EmerContactTel',
        'EmerContactDayArea',
        'EmerContactDayTel',
        'EmerContactSignature',
        'EmerContactSignerName',
        'PertinenceSpecification',
        'PertinenceSpecification-',
    ];

    public static function id(): string
    {
        return 'repair_ghost_patch_fields';
    }

    public static function label(): string
    {
        return 'Repair ghost Patch record fields';
    }

    public static function description(): string
    {
        return 'Discover and remove Patch/record fields in live code that reference controls absent from the app (seeds + Field: Field.Prop heuristics). Comments and strings are never modified.';
    }

    public function apply(array $documents, Report $report, array $options = []): void
    {
        $catalog = AppControlCatalog::build($documents);
        $ghosts = $this->discoverGhosts($documents, $catalog);
        if ($ghosts === []) {
            return;
        }

        foreach ($documents as $doc) {
            $doc->transformFormulas(function (string $formula, string $path) use ($ghosts, $report): string {
                $changed = false;
                // Preserving literals keeps LookUp(... "Field" ...).Child contiguous —
                // transformCode alone splits on "..." and breaks paren balancing.
                $out = PowerFxFormulaSegments::transformCodePreservingLiterals($formula, static function (string $code) use ($ghosts, $report, $path, &$changed): string {
                    $new = $code;
                    foreach (array_keys($ghosts) as $ghost) {
                        if (AppDataContext::isKnownEnumType((string) $ghost)) {
                            continue;
                        }
                        $linePatterns = [
                            '/^[ \t]*' . preg_quote($ghost, '/') . '\s*:\s*' . preg_quote($ghost, '/') . '\.\w+\s*,?[ \t]*\r?\n/m',
                            '/^[ \t]*' . preg_quote($ghost, '/') . '\s*:\s*' . preg_quote($ghost, '/') . '\s*,?[ \t]*\r?\n/m',
                            '/^[ \t]*' . preg_quote($ghost, '/') . '\s*:\s*' . preg_quote($ghost, '/') . '\.\w+\s*,?[ \t]*(?=\})/m',
                            '/^[ \t]*' . preg_quote($ghost, '/') . '\s*:\s*' . preg_quote($ghost, '/') . '\s*,?[ \t]*(?=\})/m',
                        ];
                        foreach ($linePatterns as $pattern) {
                            $replaced = preg_replace($pattern, '', $new);
                            if ($replaced !== null && $replaced !== $new) {
                                $report->add(self::id(), $path, $ghost, '(ghost control line)', '(removed)');
                                $new = $replaced;
                                $changed = true;
                            }
                        }
                        foreach (['Checked', 'Text', 'HtmlText', 'SelectedDate', 'Value'] as $prop) {
                            $bare = '/(?<![\w.])' . preg_quote($ghost, '/') . '\.' . $prop . '(?!\w)/';
                            $replaced = preg_replace($bare, 'false', $new);
                            if ($replaced !== null && $replaced !== $new) {
                                $report->add(self::id(), $path, $ghost . '.' . $prop, '(ghost)', 'false');
                                $new = $replaced;
                                $changed = true;
                            }
                        }
                        // LookUp(Ghost.AllItems, …).Child.Prop → Blank() when gallery is gone.
                        $neutralized = self::neutralizeGhostLookups($new, $ghost);
                        if ($neutralized !== $new) {
                            $report->add(self::id(), $path, $ghost . '.AllItems', '(ghost LookUp)', 'Blank()');
                            $new = $neutralized;
                            $changed = true;
                        }
                    }

                    return $new;
                });

                return $changed ? $out : $formula;
            });
        }
    }

    /**
     * @param list<\PowerSweeper\ControlDocument> $documents
     * @return array<string, true>
     */
    private function discoverGhosts(array $documents, AppControlCatalog $catalog): array
    {
        $candidates = [];
        foreach (self::GHOST_SEEDS as $name) {
            $candidates[$name] = true;
        }

        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                foreach ($control->propertyNames() as $prop) {
                    $value = $control->getProperty($prop);
                    if ($value === null || trim($value) === '') {
                        continue;
                    }
                    PowerFxFormulaSegments::transformCode($value, static function (string $code) use (&$candidates): string {
                        // Patch-style control mirrors: Field: Field.Checked / Field: Field
                        // Do NOT treat enum record fields (Icon: Icon.Home) as ghosts — require
                        // a control property suffix, or a bare Field: Field line.
                        if (preg_match_all(
                            '/^[ \t]*([A-Za-z_][\w\-]*)\s*:\s*\1\.(?:Checked|Text|HtmlText|SelectedDate|Value|Selected|Default|TextColor|Fill)\s*,?\s*$/m',
                            $code,
                            $m,
                        )) {
                            foreach ($m[1] as $name) {
                                $candidates[$name] = true;
                            }
                        }
                        if (preg_match_all(
                            '/^[ \t]*([A-Za-z_][\w\-]*)\s*:\s*\1\s*,?\s*$/m',
                            $code,
                            $m,
                        )) {
                            foreach ($m[1] as $name) {
                                $candidates[$name] = true;
                            }
                        }
                        // Gallery3.AllItems / MissingList.AllItems — deleted data hosts.
                        if (preg_match_all('/\b([A-Za-z_][\w]*)\.AllItems\b/', $code, $m)) {
                            foreach ($m[1] as $name) {
                                $candidates[$name] = true;
                            }
                        }

                        return $code;
                    });
                }
            }
        }

        $ghosts = [];
        foreach (array_keys($candidates) as $name) {
            if ($catalog->isReserved($name)) {
                continue;
            }
            if (AppDataContext::isKnownEnumType($name)) {
                continue;
            }
            if ($catalog->isScreenName($name)) {
                continue;
            }
            if ($catalog->screensWith($name) !== []) {
                continue;
            }
            if ($catalog->isComponentInstance($name)) {
                continue;
            }
            $ghosts[$name] = true;
        }

        return $ghosts;
    }

    /**
     * LookUp(Ghost.AllItems, pred).Child.Prop → Blank()
     */
    private static function neutralizeGhostLookups(string $code, string $ghost): string
    {
        $needle = 'LookUp';
        $out = '';
        $offset = 0;
        $len = strlen($code);
        $ghostAll = $ghost . '.AllItems';
        while ($offset < $len) {
            $pos = stripos($code, $needle, $offset);
            if ($pos === false) {
                $out .= substr($code, $offset);
                break;
            }
            $out .= substr($code, $offset, $pos - $offset);
            $open = strpos($code, '(', $pos);
            if ($open === false) {
                $out .= substr($code, $pos, strlen($needle));
                $offset = $pos + strlen($needle);
                continue;
            }
            $depth = 0;
            $i = $open;
            for (; $i < $len; $i++) {
                if ($code[$i] === '(') {
                    $depth++;
                } elseif ($code[$i] === ')') {
                    $depth--;
                    if ($depth === 0) {
                        break;
                    }
                }
            }
            if ($depth !== 0) {
                $out .= substr($code, $pos, strlen($needle));
                $offset = $pos + strlen($needle);
                continue;
            }
            $call = substr($code, $pos, $i - $pos + 1);
            $end = $i + 1;
            while ($end < $len && preg_match('/\G\.\w+/', $code, $mm, 0, $end) === 1) {
                $end += strlen($mm[0]);
            }
            $full = substr($code, $pos, $end - $pos);
            if (str_contains($call, $ghostAll)) {
                $out .= 'Blank()';
            } else {
                $out .= $full;
            }
            $offset = $end;
        }

        return $out;
    }
}
