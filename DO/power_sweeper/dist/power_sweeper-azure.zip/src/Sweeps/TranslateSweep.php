<?php

declare(strict_types=1);

namespace PowerSweeper\Sweeps;

use PowerSweeper\ControlDocument;
use PowerSweeper\ControlNaming;
use PowerSweeper\ControlNode;
use PowerSweeper\LangTableHarvester;
use PowerSweeper\SweepOptions;
use PowerSweeper\Report;

/**
 * Centralize UI strings behind language packs (dark-mode analogue for text).
 *
 * App.OnStart defines:
 *   gblLang     — optional language code ("en", "fr") when the app has no varLang
 *   gblStrings  — one record per token with En/Fr side-by-side for translators
 *
 * Literal Text / HintText / Tooltip / TrueText / FalseText become
 *   If(varLang, gblStrings.Token.En, gblStrings.Token.Fr)
 * so existing EN/FR header buttons and settings radios update live (no pack swap).
 * Existing language radios / varLang toggles are detected and wired when present.
 */
final class TranslateSweep implements SweepInterface
{
    private const LANG = 'gblLang';
    private const STRINGS = 'gblStrings';
    private const STRINGS_EN = 'gblStringsEn';
    private const STRINGS_FR = 'gblStringsFr';
    private const RADIO_NAME = 'rdoPowerSweeperLanguage';
    private const BLOCK_START = '/* ps-i18n:start */';
    private const BLOCK_END = '/* ps-i18n:end */';

    /** @var list<string> */
    private const TEXT_PROPERTIES = [
        'Text',
        'HintText',
        'Tooltip',
        'TrueText',
        'FalseText',
        'AccessibleLabel',
    ];

    public static function id(): string
    {
        return 'translate';
    }

    public static function label(): string
    {
        return 'Translate (language packs)';
    }

    public static function description(): string
    {
        return 'Centralize label/button/text into gblStrings with En/Fr side-by-side; bind controls to If(varLang, gblStrings.Token.En, gblStrings.Token.Fr) so existing English/French / EN/FR toggles update live.';
    }

    public function apply(array $documents, Report $report, array $options = []): void
    {
        $langVar = is_string($options['lang_var'] ?? null) && $options['lang_var'] !== ''
            ? (string) $options['lang_var']
            : self::LANG;
        $stringsVar = is_string($options['strings_var'] ?? null) && $options['strings_var'] !== ''
            ? (string) $options['strings_var']
            : self::STRINGS;
        $stringsEn = is_string($options['strings_en_var'] ?? null) && $options['strings_en_var'] !== ''
            ? (string) $options['strings_en_var']
            : self::STRINGS_EN;
        $stringsFr = is_string($options['strings_fr_var'] ?? null) && $options['strings_fr_var'] !== ''
            ? (string) $options['strings_fr_var']
            : self::STRINGS_FR;
        $injectToggle = !array_key_exists('inject_toggle', $options) || (bool) $options['inject_toggle'];
        $force = SweepOptions::force($options);

        /** @var array<string, array{en:string,fr:string}> $packs */
        $packs = [];
        /** @var array<string, string> $literalToToken */
        $literalToToken = [];
        /** @var array<string, string> $commentTokens */
        $commentTokens = [];
        /** @var list<array{control:ControlNode,property:string,kind:string,en:string,fr:?string}> $targets */
        $targets = [];

        $existingLangVar = $this->detectExistingLangVar($documents) ?? 'varLang';
        $langIsBoolean = $this->langVarIsBoolean($documents, $existingLangVar);
        $this->stripStrayLanguageToggles($documents, [$existingLangVar, $langVar], $report);
        $langControls = $this->findLanguageControls($documents, $existingLangVar);

        // Pass 0 — harvest EN/FR pairs from App.Formulas LangFilter tables (StatusTable, …)
        // and keep any already-written gblStrings pack (re-run after labels are bound).
        foreach ($this->findAllApps($documents) as $appControl) {
            $formulas = (string) ($appControl->getProperty('Formulas') ?? '');
            if ($formulas !== '' && str_contains($formulas, 'LangFilter')) {
                foreach (LangTableHarvester::harvest($formulas) as $token => $pair) {
                    if (!isset($packs[$token])) {
                        $packs[$token] = $pair;
                        $literalToToken[mb_strtolower($pair['en'])] = $token;
                    }
                }
            }
            foreach ($this->harvestExistingStringPack((string) ($appControl->getProperty('OnStart') ?? '')) as $token => $pair) {
                if ($this->isCommentOnly($pair['en']) || $this->isTechnicalLiteral($pair['en'])) {
                    $commentTokens[$token] = $pair['en'];
                    continue;
                }
                if (!isset($packs[$token])) {
                    $packs[$token] = $pair;
                    $literalToToken[mb_strtolower($pair['en'])] = $token;
                } elseif ($packs[$token]['fr'] === $packs[$token]['en'] && $pair['fr'] !== $pair['en']) {
                    $packs[$token]['fr'] = $pair['fr'];
                }
            }
        }
        $this->restoreCommentBindings($documents, $commentTokens, $stringsVar, $report);

        // Pass 1 — harvest literals / simple bilingual If(varLang, …) strings.
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if ($control->isApp() || $control->isScreen()) {
                    continue;
                }
                if (!$this->isTextualControl($control)) {
                    continue;
                }
                if ($this->isLanguageControlPath($langControls, $control->path)) {
                    continue;
                }
                if ($control->name === self::RADIO_NAME) {
                    continue;
                }

                foreach (self::TEXT_PROPERTIES as $prop) {
                    $raw = $control->getProperty($prop);
                    if ($raw === null || ControlNaming::isBlank($raw)) {
                        continue;
                    }
                    if ($this->isCommentOnly((string) $raw)) {
                        continue;
                    }
                    if ($this->alreadyBoundToStrings($raw, $stringsVar)) {
                        continue;
                    }
                    if ($this->alreadyBoundToTranslations($raw)) {
                        continue;
                    }

                    $bilingual = $this->parseBilingualIf($raw, $existingLangVar);
                    if ($bilingual !== null) {
                        if ($this->isIgnorableGlyph($bilingual['en']) && $this->isIgnorableGlyph($bilingual['fr'])) {
                            continue;
                        }
                        $token = $this->tokenFor($control, $prop, $bilingual['en'], $packs, $literalToToken);
                        $packs[$token]['en'] = $bilingual['en'];
                        $packs[$token]['fr'] = $bilingual['fr'];
                        $targets[] = [
                            'control' => $control,
                            'property' => $prop,
                            'kind' => 'bilingual',
                            'en' => $bilingual['en'],
                            'fr' => $bilingual['fr'],
                            'token' => $token,
                        ];
                        continue;
                    }

                    $concat = $this->parseConcatLiteral($raw);
                    if ($concat !== null) {
                        $token = $this->tokenFor($control, $prop, $concat['literal'], $packs, $literalToToken);
                        if (!isset($packs[$token])) {
                            $packs[$token] = ['en' => $concat['literal'], 'fr' => $concat['literal']];
                        }
                        $targets[] = [
                            'control' => $control,
                            'property' => $prop,
                            'kind' => $concat['side'] === 'prefix' ? 'concat_prefix' : 'concat_suffix',
                            'en' => $concat['literal'],
                            'fr' => $concat['literal'],
                            'token' => $token,
                            'rest' => $concat['rest'],
                        ];
                        continue;
                    }

                    if ($this->isDynamicExpression($raw) && !$force) {
                        continue;
                    }
                    if ($this->isDynamicExpression($raw) && $force) {
                        // force still skips rich formulas (LookUp/Concatenate/…) — only literals.
                        continue;
                    }

                    $literal = ControlNaming::unwrap($raw);
                    if ($literal === '' || $this->isIgnorableGlyph($literal) || $this->isCommentOnly($literal)) {
                        continue;
                    }

                    $token = $this->tokenFor($control, $prop, $literal, $packs, $literalToToken);
                    if (!isset($packs[$token])) {
                        $packs[$token] = ['en' => $literal, 'fr' => $literal];
                    }
                    $targets[] = [
                        'control' => $control,
                        'property' => $prop,
                        'kind' => 'literal',
                        'en' => $literal,
                        'fr' => $literal,
                        'token' => $token,
                    ];
                }
            }
        }

        // Pass 1b — gallery Items tables, HtmlText copy, DataSourceInfo display names,
        // and quoted UI literals inside If/Concatenate (Good Morning, card titles, …).
        $tableBound = [];
        $this->rewriteEmbeddedStrings(
            $documents,
            $langControls,
            $packs,
            $literalToToken,
            $stringsVar,
            $existingLangVar,
            $langIsBoolean,
            $report,
            $tableBound
        );
        $this->rewriteTableLiteralComparisons(
            $documents,
            $tableBound,
            $packs,
            $stringsVar,
            $existingLangVar,
            $langIsBoolean,
            $report
        );

        if ($packs === [] && $langControls === [] && !$injectToggle) {
            return;
        }

        // Pass 2 — inject / refresh OnStart language packs (En/Fr side-by-side).
        $apps = $this->findAllApps($documents);
        if ($apps !== []) {
            $block = $this->buildI18nBlock(
                $langVar,
                $stringsVar,
                $packs,
                $existingLangVar,
                $langIsBoolean,
                $langControls !== []
            );
            foreach ($apps as $appControl) {
                $before = (string) ($appControl->getProperty('OnStart') ?? '');
                $after = $this->upsertBlock($before, $block, $appControl->format === 'yaml');
                if ($after !== $before) {
                    $appControl->setProperty('OnStart', $after);
                    $report->add(
                        self::id(),
                        $appControl->path,
                        'OnStart',
                        $before !== '' ? $before : '(empty)',
                        $after
                    );
                }
            }
        }

        // Pass 3 — wire every language control (settings radio AND header EN/FR).
        if ($langControls !== []) {
            foreach ($langControls as $langControl) {
                $this->wireLanguageControl(
                    $langControl,
                    $langVar,
                    $existingLangVar,
                    $langIsBoolean,
                    $report
                );
            }
        } elseif ($injectToggle) {
            $screen = $this->pickIntroScreen($documents);
            if ($screen !== null) {
                $this->injectLanguageRadio(
                    $screen,
                    $langVar,
                    $stringsVar,
                    $report
                );
            }
        }

        // Pass 4 — rewrite harvested targets to If(varLang, gblStrings.Token.En, gblStrings.Token.Fr).
        foreach ($targets as $target) {
            /** @var ControlNode $control */
            $control = $target['control'];
            $prop = (string) $target['property'];
            $token = (string) $target['token'];
            $before = (string) ($control->getProperty($prop) ?? '');
            $expr = $this->stringsBinding($stringsVar, $token, $existingLangVar, $langIsBoolean);
            $kind = (string) ($target['kind'] ?? '');
            if ($kind === 'concat_prefix' && isset($target['rest'])) {
                $expr .= ' & ' . (string) $target['rest'];
            } elseif ($kind === 'concat_suffix' && isset($target['rest'])) {
                $expr = (string) $target['rest'] . ' & ' . $expr;
            }
            $to = $control->format === 'yaml' ? '=' . $expr : $expr;
            if (trim(ltrim($before, '=')) === $expr) {
                continue;
            }
            $control->setProperty($prop, $to);
            $report->add(self::id(), $control->path, $prop, $before !== '' ? $before : '(empty)', $to);
        }

        // Pass 5 — components that reference gblStrings need AccessAppScope.
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if (!$this->looksLikeComponentDefinition($control)) {
                    continue;
                }
                $needs = false;
                foreach ($control->propertyNames() as $prop) {
                    $val = (string) ($control->getProperty($prop) ?? '');
                    if (str_contains($val, $stringsVar) || str_contains($val, $langVar) || str_contains($val, $existingLangVar)) {
                        $needs = true;
                        break;
                    }
                }
                if (!$needs) {
                    continue;
                }
                $before = (string) ($control->getProperty('AccessAppScope') ?? '');
                if (strtolower(trim(ltrim($before, '='))) === 'true') {
                    continue;
                }
                $to = $control->format === 'yaml' ? '=true' : 'true';
                $control->setProperty('AccessAppScope', $to);
                $report->add(
                    self::id(),
                    $control->path,
                    'AccessAppScope',
                    $before !== '' ? $before : '(unset)',
                    $to
                );
            }
        }
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function tokenFor(
        ControlNode $control,
        string $prop,
        string $literal,
        array &$packs,
        array &$literalToToken
    ): string {
        $key = mb_strtolower($literal);
        if (isset($literalToToken[$key])) {
            return $literalToToken[$key];
        }

        $base = null;
        if (!ControlNaming::isGenericName($control->name) && ControlNaming::isValidIdentifier($control->name)) {
            $base = $control->name;
            if ($prop !== 'Text') {
                $base .= $this->pascal($prop);
            }
        }
        if ($base === null) {
            $base = $this->pascal($literal);
        }
        if ($base === '' || !ControlNaming::isValidIdentifier($base)) {
            $base = 'String' . (count($packs) + 1);
        }
        $token = $base;
        $n = 2;
        while (isset($packs[$token]) && $packs[$token]['en'] !== $literal) {
            $token = $base . $n;
            $n++;
        }
        $literalToToken[$key] = $token;

        return $token;
    }

    private function pascal(string $text): string
    {
        $clean = preg_replace('/[^A-Za-z0-9]+/', ' ', $text) ?? $text;
        $parts = preg_split('/\s+/', trim($clean)) ?: [];
        $out = '';
        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            $out .= ucfirst(strtolower($part));
        }
        if ($out !== '' && preg_match('/^\d/', $out)) {
            $out = 'T' . $out;
        }

        return substr($out, 0, 48);
    }

    private function isTextualControl(ControlNode $control): bool
    {
        $t = strtolower($control->type . ' ' . $control->name);
        foreach ([
            'label', 'button', 'text', 'htmltext', 'htmlviewer', 'textbox', 'textinput',
            'checkbox', 'toggle', 'switch', 'radio', 'dropdown', 'combobox', 'datepicker',
            'link', 'icon', 'header', 'footer', 'info',
        ] as $needle) {
            if (str_contains($t, $needle)) {
                return true;
            }
        }
        foreach (self::TEXT_PROPERTIES as $prop) {
            if ($control->getProperty($prop) !== null) {
                return true;
            }
        }

        return false;
    }

    /** Power Fx comment-only formula — blank at runtime, not UI copy. */
    private function isCommentOnly(string $raw): bool
    {
        $v = trim(ltrim(trim($raw), '='));

        return str_starts_with($v, '//');
    }

    /**
     * Undo gblStrings bindings that are not UI copy: // placeholders (Studio then
     * tries Value(...) → "cannot be converted to a number") and CSS fragments.
     *
     * @param list<ControlDocument> $documents
     * @param array<string, string> $commentTokens
     */
    private function restoreCommentBindings(
        array $documents,
        array $commentTokens,
        string $stringsVar,
        Report $report
    ): void {
        if ($commentTokens === []) {
            return;
        }
        $q = preg_quote($stringsVar, '/');
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                foreach ($control->propertyNames() as $prop) {
                    $raw = (string) ($control->getProperty($prop) ?? '');
                    if ($raw === '' || !str_contains($raw, $stringsVar)) {
                        continue;
                    }
                    $next = $raw;
                    foreach ($commentTokens as $token => $en) {
                        $tq = preg_quote($token, '/');
                        $ifRe = '/If\s*\(\s*(?:Or\s*\([^)]*\)|[A-Za-z_]\w*)\s*,\s*'
                            . $q . '\s*\.\s*' . $tq . '\s*\.\s*En\s*,\s*'
                            . $q . '\s*\.\s*' . $tq . '\s*\.\s*Fr\s*\)/';
                        $replacement = $this->isCommentOnly($en)
                            ? $en
                            : '"' . $this->escapeFx($en) . '"';
                        $next = preg_replace($ifRe, $replacement, $next) ?? $next;
                    }
                    if ($next === $raw) {
                        continue;
                    }
                    $body = trim(ltrim(trim($next), '='));
                    if ($this->isCommentOnly($body)) {
                        $next = $control->format === 'yaml' ? '=' . $body : $body;
                    }
                    $control->setProperty($prop, $next);
                    $report->add(self::id(), $control->path, $prop, $raw, $next);
                }
            }
        }
    }

    /** CSS / unit fragments that must stay quoted concatenations, not gblStrings. */
    private function isTechnicalLiteral(string $raw): bool
    {
        $t = trim(ltrim(trim($raw), '='));
        if ($t === '') {
            return false;
        }
        if (preg_match('/^px\b/i', $t) === 1) {
            return true;
        }
        if (preg_match('/^(width|height|min-width|max-width|min-height|max-height|background|background-color|color|border|padding|margin|font-size|font-family|display|overflow|box-shadow|border-radius)\s*:/i', $t) === 1) {
            return true;
        }

        return preg_match('/^\s*[\d.]+\s*(px|em|rem|%|vh|vw)\s*;?\s*$/i', $t) === 1;
    }

    private function isIgnorableGlyph(string $literal): bool
    {
        $t = trim($literal);
        if ($t === '') {
            return true;
        }
        // Single punctuation / arrows / emoji-only chips.
        if (preg_match('/^[\p{P}\p{S}\s]+$/u', $t) === 1 && mb_strlen($t) <= 3) {
            return true;
        }
        // Header EN/FR chips stay If(varLang, "EN", "FR") — not gblStrings.En.En.
        if (preg_match('/^(en|fr|en-ca|fr-ca)$/i', $t) === 1) {
            return true;
        }

        return false;
    }

    private function alreadyBoundToStrings(string $raw, string $stringsVar): bool
    {
        $q = preg_quote($stringsVar, '/');

        return (bool) preg_match('/\b' . $q . '\s*\.\s*\w+\s*\.\s*(En|Fr)\b/', $raw);
    }

    private function alreadyBoundToTranslations(string $raw): bool
    {
        return (bool) preg_match(
            '/\bcomTranslations\s*\.\s*Labels\b|\bTranslationComponent\w*\s*\.\s*Labels\b|\b(?:LookUp|Filter)\s*\(\s*\w*(?:Table|Labels)\w*\s*,\s*LangFilter\s*=|\bLangFilter\s*=\s*If\s*\(\s*!?varLang/i',
            $raw
        );
    }

    private function isDynamicExpression(string $value): bool
    {
        $v = trim($value);
        if (str_starts_with($v, '=')) {
            $v = trim(substr($v, 1));
        }
        if ($v === '') {
            return false;
        }
        if (
            (str_starts_with($v, '"') && str_ends_with($v, '"') && substr_count($v, '"') === 2)
            || (str_starts_with($v, "'") && str_ends_with($v, "'") && substr_count($v, "'") === 2)
        ) {
            return false;
        }

        return (bool) preg_match(
            '/\b(If|Switch|LookUp|Coalesce|Concatenate|With|Filter)\s*\(|\b(Self|Parent|ThisItem|var[A-Z]|com[A-Z]|gbl[A-Z])\b|[()&]|[A-Za-z_]\w*\./i',
            $v
        );
    }

    /**
     * @return null|array{en:string,fr:string}
     */
    private function parseBilingualIf(string $raw, string $langVar): ?array
    {
        $v = trim($raw);
        if (str_starts_with($v, '=')) {
            $v = trim(substr($v, 1));
        }
        // If(varLang, "EN", "FR") or If(varLang=true, …) / If(!varLang, fr, en)
        $q = preg_quote($langVar, '/');
        if (preg_match('/^If\s*\(\s*!?\s*' . $q . '\s*(?:=\s*true)?\s*,\s*"([^"]*)"\s*,\s*"([^"]*)"\s*\)$/is', $v, $m)) {
            $negated = str_contains(substr($v, 0, strpos($v, ',') ?: 0), '!');
            if ($negated) {
                return ['en' => $m[2], 'fr' => $m[1]];
            }

            return ['en' => $m[1], 'fr' => $m[2]];
        }
        if (preg_match('/^If\s*\(\s*' . $q . '\s*,\s*"([^"]*)"\s*,\s*"([^"]*)"\s*\)$/is', $v, $m)) {
            return ['en' => $m[1], 'fr' => $m[2]];
        }

        return null;
    }

    /** @param list<ControlDocument> $documents */
    private function detectExistingLangVar(array $documents): ?string
    {
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                foreach (['OnChange', 'OnSelect', 'OnCheck', 'OnUncheck', 'OnStart', 'Default'] as $prop) {
                    $val = (string) ($control->getProperty($prop) ?? '');
                    if (preg_match('/\bSet\s*\(\s*(varLang|gblLang)\s*,/i', $val, $m)) {
                        return $m[1];
                    }
                    if (preg_match('/\b(varLang|gblLang)\b/', $val, $m) && str_contains(strtolower($control->name), 'lang')) {
                        return $m[1];
                    }
                }
            }
        }

        return null;
    }

    /**
     * @param list<ControlDocument> $documents
     * @return list<ControlNode>
     */
    private function findLanguageControls(array $documents, string $langVar): array
    {
        $found = [];
        $q = preg_quote($langVar, '/');
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                $type = strtolower($control->type);
                $onSelect = (string) ($control->getProperty('OnSelect') ?? '');
                $onChange = (string) ($control->getProperty('OnChange') ?? '');
                $setsLang = preg_match('/\bSet\s*\(\s*' . $q . '\s*,/i', $onSelect . ' ' . $onChange) === 1;
                $isChooser = str_contains($type, 'radio')
                    || str_contains($type, 'dropdown')
                    || str_contains($type, 'combobox')
                    || $control->isToggle()
                    || str_contains(strtolower($control->name), 'toggle')
                    || $control->isButtonLike()
                    || (str_contains($type, 'label') && $setsLang);
                if (!$isChooser && !$setsLang) {
                    continue;
                }
                // Bound labels are If(varLang, gblStrings.X.En, …) — that is not a language toggle.
                $text = (string) ($control->getProperty('Text') ?? '');
                $textForScore = $this->alreadyBoundToStrings($text, self::STRINGS) ? '' : $text;
                $labelBlob = strtolower(
                    $control->name . ' '
                    . $textForScore . ' '
                    . (string) ($control->getProperty('AccessibleLabel') ?? '')
                    . ' '
                    . (string) ($control->getProperty('Items') ?? '')
                );
                $blob = $labelBlob . ' ' . strtolower($onChange . ' ' . $onSelect);
                $score = 0;
                if (str_contains($labelBlob, 'language') || str_contains($labelBlob, 'langue')) {
                    $score += 50;
                }
                if (str_contains($labelBlob, 'english') && str_contains($labelBlob, 'french')) {
                    $score += 80;
                }
                if (str_contains($labelBlob, 'english') || str_contains($labelBlob, 'french')) {
                    $score += 30;
                }
                if ($setsLang) {
                    $score += 100;
                }
                if (preg_match('/\b(en|fr|en-ca|fr-ca)\b/', $labelBlob)) {
                    $score += 10;
                }
                // Exclude dark-theme radios.
                if (
                    (str_contains($blob, 'dark') || str_contains($blob, 'light') || str_contains($blob, 'theme'))
                    && !str_contains($labelBlob, 'english')
                    && !str_contains($labelBlob, 'french')
                    && !str_contains($labelBlob, 'language')
                    && !$setsLang
                ) {
                    $score -= 100;
                }
                // Buttons that only mention varLang in a gblStrings Text binding are CTAs, not toggles.
                if ($control->isButtonLike() && !$setsLang && !str_contains($blob, 'english') && !str_contains($blob, 'french')) {
                    continue;
                }
                if ($score >= 40) {
                    $found[] = $control;
                }
            }
        }

        return $found;
    }

    /** @param list<ControlNode> $langControls */
    private function isLanguageControlPath(array $langControls, string $path): bool
    {
        foreach ($langControls as $control) {
            if ($control->path === $path) {
                return true;
            }
        }

        return false;
    }

    /** @param list<ControlDocument> $documents */
    private function langVarIsBoolean(array $documents, string $langVar): bool
    {
        $q = preg_quote($langVar, '/');
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                foreach (['OnChange', 'OnSelect', 'OnCheck', 'OnUncheck', 'OnStart', 'Default'] as $prop) {
                    $val = (string) ($control->getProperty($prop) ?? '');
                    if (preg_match('/\bSet\s*\(\s*' . $q . '\s*,\s*(true|false|!' . $q . ')/i', $val) === 1) {
                        return true;
                    }
                    if (preg_match('/\bIf\s*\(\s*!' . $q . '\s*,/', $val) === 1) {
                        return true;
                    }
                }
            }
        }

        return strcasecmp($langVar, 'varLang') === 0;
    }

    private function stringsBinding(string $stringsVar, string $token, string $langVar, bool $langIsBoolean): string
    {
        $en = $stringsVar . '.' . $token . '.En';
        $fr = $stringsVar . '.' . $token . '.Fr';
        if ($langIsBoolean) {
            return 'If(' . $langVar . ', ' . $en . ', ' . $fr . ')';
        }

        return 'If(Or(' . $langVar . ' = "fr", ' . $langVar . ' = "FR"), ' . $fr . ', ' . $en . ')';
    }

    private function wireLanguageControl(
        ControlNode $control,
        string $langVar,
        string $existingLangVar,
        bool $langIsBoolean,
        Report $report
    ): void {
        $type = strtolower($control->type);
        $activeVar = $langIsBoolean ? $existingLangVar : $langVar;

        if (str_contains($type, 'radio') || str_contains($type, 'dropdown') || str_contains($type, 'combobox')) {
            $this->ensureLanguageItems($control, $activeVar, $langIsBoolean, $report);
            $setLang = $langIsBoolean
                ? 'Set(' . $existingLangVar . ', ' . $this->selectedEnglishExpr() . ')'
                : 'Set(' . $langVar . ', If(' . $this->selectedEnglishExpr() . ', "en", "fr"))';
            $this->replaceLangOnlyFormula($control, 'OnChange', $setLang, [$existingLangVar, $langVar], $report);
            $this->replaceLangOnlyFormula($control, 'OnSelect', $setLang, [$existingLangVar, $langVar], $report);

            return;
        }

        if ($control->isToggle() || str_contains(strtolower($control->name), 'toggle')) {
            $onCheck = $langIsBoolean
                ? 'Set(' . $existingLangVar . ', false)'
                : 'Set(' . $langVar . ', "fr")';
            $onUncheck = $langIsBoolean
                ? 'Set(' . $existingLangVar . ', true)'
                : 'Set(' . $langVar . ', "en")';
            $this->replaceLangOnlyFormula($control, 'OnCheck', $onCheck, [$existingLangVar, $langVar], $report);
            $this->replaceLangOnlyFormula($control, 'OnUncheck', $onUncheck, [$existingLangVar, $langVar], $report);

            return;
        }

        if ($control->isButtonLike() || str_contains($type, 'label')) {
            $toggle = $langIsBoolean
                ? 'Set(' . $existingLangVar . ', !Coalesce(' . $existingLangVar . ', true))'
                : 'Set(' . $langVar . ', If(Or(' . $langVar . ' = "fr", ' . $langVar . ' = "FR"), "en", "fr"))';
            $this->replaceLangOnlyFormula($control, 'OnSelect', $toggle, [$existingLangVar, $langVar], $report);
        }
    }

    /**
     * Fluent Radio@0.0.x keeps Selected as a string when Items is ["English","French"].
     * Self.Selected.Value (and record Items) error at authoring time so OnChange never runs.
     */
    private function ensureLanguageItems(
        ControlNode $control,
        string $langVar,
        bool $langIsBoolean,
        Report $report
    ): void {
        $items = (string) ($control->getProperty('Items') ?? '');
        $wantItems = $control->format === 'yaml'
            ? '=["English", "French"]'
            : '["English", "French"]';
        $itemsBody = trim(ltrim(trim($items), '='));
        $alreadyString = preg_match('/^\[\s*"English"\s*,\s*"French"\s*\]$/i', $itemsBody) === 1
            && !str_contains($items, 'Value:');
        if (!$alreadyString) {
            $control->setProperty('Items', $wantItems);
            $report->add(self::id(), $control->path, 'Items', $items !== '' ? $items : '(unset)', $wantItems);
        }

        $default = (string) ($control->getProperty('DefaultSelectedItems') ?? '');
        $expr = $langIsBoolean
            ? 'If(' . $langVar . ', ["English"], ["French"])'
            : 'If(Or(' . $langVar . ' = "fr", ' . $langVar . ' = "FR"), ["French"], ["English"])';
        $to = $control->format === 'yaml' ? '=' . $expr : $expr;
        $defaultBody = trim(ltrim(trim($default), '='));
        if ($defaultBody !== $expr) {
            $control->setProperty('DefaultSelectedItems', $to);
            $report->add(self::id(), $control->path, 'DefaultSelectedItems', $default !== '' ? $default : '(unset)', $to);
        }
    }

    private function selectedEnglishExpr(): string
    {
        return 'Self.Selected = "English"';
    }

    /** @param list<string> $langVars */
    private function replaceLangOnlyFormula(
        ControlNode $control,
        string $prop,
        string $canonical,
        array $langVars,
        Report $report
    ): void {
        $before = (string) ($control->getProperty($prop) ?? '');
        $body = trim(ltrim(trim($before), '='));
        $langOnly = $body === '' || $this->isLangOnlyFormula($body, $langVars);
        if (!$langOnly) {
            return;
        }
        $to = $control->format === 'yaml' ? '=' . $canonical : $canonical;
        if (trim(ltrim(trim($before), '=')) === $canonical) {
            return;
        }
        $control->setProperty($prop, $to);
        $report->add(self::id(), $control->path, $prop, $before !== '' ? $before : '(empty)', $to);
    }

    /**
     * Earlier translate passes appended Set(varLang, !varLang) onto real CTAs.
     * That made every such button look like a language toggle and blocked harvest.
     *
     * @param list<ControlDocument> $documents
     * @param list<string> $langVars
     */
    private function stripStrayLanguageToggles(array $documents, array $langVars, Report $report): void
    {
        $q = implode('|', array_map(static fn(string $v): string => preg_quote($v, '/'), $langVars));
        $tail = '/;\s*Set\(\s*(?:' . $q . ')\s*,\s*!?((?:Coalesce\(\s*(?:' . $q . ')\s*,\s*true\s*\))|(?:' . $q . '))\s*\)\s*;?\s*$/i';
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                foreach (['OnSelect', 'OnChange'] as $prop) {
                    $before = (string) ($control->getProperty($prop) ?? '');
                    $body = trim(ltrim(trim($before), '='));
                    if ($body === '' || $this->isLangOnlyFormula($body, $langVars)) {
                        continue;
                    }
                    $cleaned = preg_replace($tail, '', $body);
                    if (!is_string($cleaned) || $cleaned === $body) {
                        continue;
                    }
                    $cleaned = trim($cleaned);
                    $to = $control->format === 'yaml' ? '=' . $cleaned : $cleaned;
                    $control->setProperty($prop, $to);
                    $report->add(self::id(), $control->path, $prop, $before, $to);
                }
            }
        }
    }

    /** @return array{literal:string,rest:string,side:'prefix'|'suffix'}|null */
    private function parseConcatLiteral(string $raw): ?array
    {
        $v = trim(ltrim(trim($raw), '='));
        if (preg_match('/^"((?:[^"]|"")*)"\s*&\s*(.+)$/s', $v, $m) === 1) {
            $lit = str_replace('""', '"', $m[1]);
            if ($this->isIgnorableGlyph($lit) || str_starts_with(ltrim($lit), '<')) {
                return null;
            }

            return ['literal' => $lit, 'rest' => trim($m[2]), 'side' => 'prefix'];
        }
        if (preg_match('/^(.+?)\s*&\s*"((?:[^"]|"")*)"$/s', $v, $m) === 1) {
            $lit = str_replace('""', '"', $m[2]);
            if ($this->isIgnorableGlyph($lit) || str_starts_with(ltrim($lit), '<')) {
                return null;
            }

            return ['literal' => $lit, 'rest' => trim($m[1]), 'side' => 'suffix'];
        }

        return null;
    }

    /**
     * Bind UI copy that is not a lone Text= literal: gallery Tables, HtmlText, DataSourceInfo labels.
     *
     * @param list<ControlDocument> $documents
     * @param list<ControlNode> $langControls
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function rewriteEmbeddedStrings(
        array $documents,
        array $langControls,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean,
        Report $report,
        array &$tableBound = []
    ): void {
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if ($control->isApp() || $control->isScreen()) {
                    continue;
                }
                $skipItems = $this->isLanguageControlPath($langControls, $control->path);
                foreach (['Text', 'HintText', 'Tooltip', 'HtmlText', 'Items', 'DisplayName', 'AccessibleLabel'] as $prop) {
                    if ($skipItems && $prop === 'Items') {
                        continue;
                    }
                    $raw = $control->getProperty($prop);
                    if ($raw === null || ControlNaming::isBlank($raw)) {
                        continue;
                    }
                    if ($this->alreadyBoundToStrings((string) $raw, $stringsVar) && !str_contains((string) $raw, 'DataSourceInfo')) {
                        // Still rewrite remaining raw quotes / HTML phrases.
                        if (!preg_match('/"[^"]*[A-Za-z]{3,}/', (string) $raw) && !str_contains((string) $raw, 'My Account')) {
                            continue;
                        }
                    }
                    $after = $this->rewriteFormulaEmbedded(
                        (string) $raw,
                        $prop,
                        $control,
                        $packs,
                        $literalToToken,
                        $stringsVar,
                        $langVar,
                        $langIsBoolean,
                        $tableBound
                    );
                    if ($after === null || $after === (string) $raw) {
                        continue;
                    }
                    $control->setProperty($prop, $after);
                    $report->add(self::id(), $control->path, $prop, (string) $raw, $after);
                }
            }
        }
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function rewriteFormulaEmbedded(
        string $raw,
        string $prop,
        ControlNode $control,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean,
        array &$tableBound = []
    ): ?string {
        $hadEquals = str_starts_with(trim($raw), '=') || $control->format === 'yaml';
        $body = trim(ltrim(trim($raw), '='));
        $ds = $this->rewriteDataSourceDisplayName($body, $control, $packs, $literalToToken, $stringsVar, $langVar, $langIsBoolean);
        if ($ds !== null) {
            return $hadEquals ? '=' . $ds : $ds;
        }
        $next = $prop === 'Items'
            ? $this->rewriteItemsTableLiterals($body, $control, $packs, $literalToToken, $stringsVar, $langVar, $langIsBoolean, $tableBound)
            : $this->rewriteQuotedUiLiterals($body, $control, $packs, $literalToToken, $stringsVar, $langVar, $langIsBoolean);
        if ($next === $body) {
            return null;
        }

        return $hadEquals ? '=' . $next : $next;
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function rewriteDataSourceDisplayName(
        string $body,
        ControlNode $control,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean
    ): ?string {
        if (preg_match('/DataSourceInfo\s*\(\s*.+?,\s*DataSourceInfo\.DisplayName\s*,\s*(.+?)\s*\)\s*$/s', $body, $m) !== 1) {
            return null;
        }
        $field = trim($m[1]);
        $en = trim($field, "'\"");
        if ($en === '' || $this->isIgnorableGlyph($en)) {
            return null;
        }
        $token = $this->tokenFor($control, 'DisplayName', $en, $packs, $literalToToken);
        if (!isset($packs[$token])) {
            $packs[$token] = ['en' => $en, 'fr' => $en];
        }

        return $this->stringsBinding($stringsVar, $token, $langVar, $langIsBoolean);
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function rewriteItemsTableLiterals(
        string $body,
        ControlNode $control,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean,
        array &$tableBound = []
    ): string {
        $out = preg_replace_callback(
            '/\b(Title|Description|StepTitle|StepDesc|Label|Subtitle|Heading|Caption|Name)\s*:\s*"((?:[^"]|"")*)"/i',
            function (array $m) use ($control, &$packs, &$literalToToken, $stringsVar, $langVar, $langIsBoolean, &$tableBound): string {
                $lit = str_replace('""', '"', $m[2]);
                if (!$this->isUiLiteral($lit)) {
                    return $m[0];
                }
                $token = $this->tokenFor($control, $m[1], $lit, $packs, $literalToToken);
                if (!isset($packs[$token])) {
                    $packs[$token] = ['en' => $lit, 'fr' => $lit];
                }
                $tableBound[$lit] = $token;

                return $m[1] . ': ' . $this->stringsBinding($stringsVar, $token, $langVar, $langIsBoolean);
            },
            $body
        );

        return is_string($out) ? $out : $body;
    }

    /**
     * Gallery templates compare ThisItem.Title = "View My Pairing". After Items.Title
     * is localized, those comparisons must use the same gblStrings binding.
     *
     * @param list<ControlDocument> $documents
     * @param array<string, string> $tableBound
     * @param array<string, array{en:string,fr:string}> $packs
     */
    private function rewriteTableLiteralComparisons(
        array $documents,
        array $tableBound,
        array $packs,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean,
        Report $report
    ): void {
        if ($tableBound === []) {
            return;
        }
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if ($control->isApp()) {
                    continue;
                }
                foreach ($control->propertyNames() as $prop) {
                    $raw = (string) ($control->getProperty($prop) ?? '');
                    if ($raw === '') {
                        continue;
                    }
                    $next = $raw;
                    foreach ($tableBound as $lit => $token) {
                        if (!isset($packs[$token])) {
                            continue;
                        }
                        $quoted = '"' . str_replace('"', '""', $lit) . '"';
                        if (!str_contains($next, $quoted)) {
                            continue;
                        }
                        $bind = $this->stringsBinding($stringsVar, $token, $langVar, $langIsBoolean);
                        $next = str_replace($quoted, $bind, $next);
                    }
                    if ($next !== $raw) {
                        $control->setProperty($prop, $next);
                        $report->add(self::id(), $control->path, $prop, $raw, $next);
                    }
                }
            }
        }
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function rewriteQuotedUiLiterals(
        string $body,
        ControlNode $control,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean
    ): string {
        $out = preg_replace_callback(
            '/"((?:[^"]|"")*)"/s',
            function (array $m) use ($control, &$packs, &$literalToToken, $stringsVar, $langVar, $langIsBoolean): string {
                $lit = str_replace('""', '"', $m[1]);
                if (str_contains($lit, '<') && preg_match('/[A-Za-z]{3,}/', $lit) === 1) {
                    return $this->injectHtmlPhrases($m[0], $lit, $control, $packs, $literalToToken, $stringsVar, $langVar, $langIsBoolean);
                }
                if (!$this->isUiLiteral($lit)) {
                    return $m[0];
                }
                $token = $this->tokenFor($control, 'Text', $lit, $packs, $literalToToken);
                if (!isset($packs[$token])) {
                    $packs[$token] = ['en' => $lit, 'fr' => $lit];
                }

                return $this->stringsBinding($stringsVar, $token, $langVar, $langIsBoolean);
            },
            $body
        );

        return is_string($out) ? $out : $body;
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     * @param array<string, string> $literalToToken
     */
    private function injectHtmlPhrases(
        string $quoted,
        string $inner,
        ControlNode $control,
        array &$packs,
        array &$literalToToken,
        string $stringsVar,
        string $langVar,
        bool $langIsBoolean
    ): string {
        $phrases = $this->htmlPhrases();
        usort($phrases, static fn(string $a, string $b): int => mb_strlen($b) <=> mb_strlen($a));
        $chunk = $inner;
        $placeholders = [];
        $n = 0;
        foreach ($phrases as $en) {
            if ($en === '' || !str_contains(mb_strtolower($chunk), mb_strtolower($en))) {
                continue;
            }
            $token = $this->tokenFor($control, 'HtmlText', $en, $packs, $literalToToken);
            if (!isset($packs[$token])) {
                $packs[$token] = ['en' => $en, 'fr' => $en];
            }
            $ph = "\x1Ebind{$n}\x1E";
            $placeholders[$ph] = '" & ' . $this->stringsBinding($stringsVar, $token, $langVar, $langIsBoolean) . ' & "';
            $chunk = preg_replace('/' . preg_quote($en, '/') . '/iu', $ph, $chunk, 1) ?? $chunk;
            $n++;
        }
        if ($placeholders === []) {
            return $quoted;
        }
        $wrapped = '"' . str_replace('"', '""', $chunk) . '"';

        return strtr($wrapped, $placeholders);
    }

    /** @return list<string> */
    private function htmlPhrases(): array
    {
        return [
            'View and manage your account details and participant information.',
            "Please Fill In All Information Truthfully. Click 'Next!' to continue.",
            'Please Fill In All Information Truthfully. Click \'Next!\' to continue.',
            'TDR — My Account',
            'TDR - My Account',
            'My Account',
            'My Profile',
            'Admin Portal',
        ];
    }

    private function isUiLiteral(string $lit): bool
    {
        $t = trim($lit);
        if ($t === '' || $this->isIgnorableGlyph($t) || $this->isCommentOnly($t) || $this->isTechnicalLiteral($t)) {
            return false;
        }
        if (preg_match('/^(english|french)$/i', $t) === 1) {
            return false;
        }
        if (preg_match('/^(data:|https?:|#[0-9A-Fa-f]{3,8}$)/i', $t) === 1) {
            return false;
        }
        if (str_starts_with($t, '<') || str_contains($t, 'data:image') || str_contains($t, '<svg')) {
            return false;
        }
        if (preg_match('/[A-Za-z]/', $t) !== 1) {
            return false;
        }
        if (mb_strlen($t) < 2) {
            return false;
        }

        return true;
    }

    /** @param list<string> $langVars */
    private function isLangOnlyFormula(string $body, array $langVars): bool
    {
        if (preg_match('/\b(Navigate|Patch|Collect|ClearCollect|Notify|Remove|Refresh|UpdateContext)\b/i', $body) === 1) {
            return false;
        }
        $q = implode('|', array_map(static fn(string $v): string => preg_quote($v, '/'), $langVars));

        return preg_match('/\bSet\s*\(\s*(?:' . $q . ')\s*,/i', $body) === 1
            || preg_match('/\bIf\s*\(\s*(?:Self\.Selected|!' . $q . '|' . $q . ')/i', $body) === 1;
    }

    private function formulaAlreadyCanonical(string $body, string $canonical): bool
    {
        $norm = static fn(string $s): string => strtolower(preg_replace('/\s+/', '', $s) ?? $s);

        return str_contains($norm($body), $norm($canonical));
    }

    private function injectLanguageRadio(
        ControlNode $screen,
        string $langVar,
        string $stringsVar,
        Report $report
    ): void {
        $onChange = 'Set(' . $langVar . ', If(' . $this->selectedEnglishExpr() . ', "en", "fr"))';
        $screen->addYamlChild(self::RADIO_NAME, [
            'Control' => 'Classic/Radio@2.1.0',
            'Properties' => [
                'Items' => '=[{Value: "English"}, {Value: "French"}]',
                'Layout' => '=Layout.Horizontal',
                'AccessibleLabel' => '="Language"',
                'Tooltip' => '="Switch UI language — edit En/Fr side-by-side in App.OnStart ' . $stringsVar . '"',
                'DefaultSelectedItems' => '=If(' . $langVar . ' = "fr", [{Value: "French"}], [{Value: "English"}])',
                'OnChange' => '=' . $onChange,
                'X' => '=16',
                'Y' => '=64',
                'Width' => '=260',
                'Height' => '=40',
            ],
        ]);
        $report->add(
            self::id(),
            $screen->path,
            'Children',
            '(missing language control)',
            self::RADIO_NAME . ' injected'
        );
    }

    /**
     * @param array<string, array{en:string,fr:string}> $packs
     */
    private function buildI18nBlock(
        string $langVar,
        string $stringsVar,
        array $packs,
        string $existingLangVar,
        bool $langIsBoolean,
        bool $hasLangControl
    ): string {
        ksort($packs);
        $fields = [];
        foreach ($packs as $token => $pair) {
            $fr = $pair['fr'];
            if ($fr === $pair['en']) {
                $fr = $this->frenchFallback($pair['en']);
            }
            $fields[] = $token . ': { En: "' . $this->escapeFx($pair['en']) . '", Fr: "' . $this->escapeFx($fr) . '" }';
        }
        if ($fields === []) {
            $fields[] = 'Placeholder: { En: "", Fr: "" }';
        }

        $init = '';
        if ($langIsBoolean) {
            $init = 'Set(' . $existingLangVar . ', Coalesce(' . $existingLangVar . ', true));';
        } elseif ($hasLangControl && $existingLangVar !== $langVar) {
            $init = 'Set(' . $langVar . ', If(Or(' . $existingLangVar . ' = false, ' . $existingLangVar . ' = "FR", ' . $existingLangVar . ' = "fr", ' . $existingLangVar . ' = "fr-ca"), "fr", "en"));';
        } else {
            $init = 'If(IsBlank(' . $langVar . '), Set(' . $langVar . ', "en"));';
        }

        return self::BLOCK_START
            . " /* En/Fr side-by-side — translators edit Fr */\n"
            . $init . "\n"
            . 'Set(' . $stringsVar . ', {' . "\n    " . implode(",\n    ", $fields) . "\n})\n"
            . self::BLOCK_END;
    }

    private function escapeFx(string $s): string
    {
        return str_replace(['\\', '"'], ['\\\\', '""'], $s);
    }

    /**
     * Keep an already-translated gblStrings pack when translate is re-run
     * (control Text is already If(varLang, gblStrings.X.En, …) so Pass 1 would drop it).
     *
     * @return array<string, array{en:string,fr:string}>
     */
    private function harvestExistingStringPack(string $onStart): array
    {
        $packs = [];
        if (!str_contains($onStart, self::BLOCK_START) || !str_contains($onStart, '{ En:')) {
            return $packs;
        }
        if (preg_match_all(
            '/(\b[A-Za-z_][A-Za-z0-9_]*)\s*:\s*\{\s*En:\s*"((?:[^"]|"")*)"\s*,\s*Fr:\s*"((?:[^"]|"")*)"\s*\}/s',
            $onStart,
            $m,
            PREG_SET_ORDER
        ) !== false) {
            foreach ($m as $row) {
                $packs[$row[1]] = [
                    'en' => str_replace('""', '"', $row[2]),
                    'fr' => str_replace('""', '"', $row[3]),
                ];
            }
        }

        return $packs;
    }

    /** Common hallway / settings chrome so EN/FR is visible before translators fill Fr. */
    private function frenchFallback(string $en): string
    {
        $trimmed = trim($en);
        if ($trimmed === '' || str_starts_with($trimmed, '//') || str_starts_with($trimmed, 'var')) {
            return $en;
        }
        $key = mb_strtolower((string) preg_replace('/\s+/u', ' ', $trimmed));
        static $map = null;
        if ($map === null) {
            $file = POWER_SWEEPER_ROOT . '/config/french_ui_strings.php';
            $loaded = is_file($file) ? require $file : [];
            $map = is_array($loaded) ? $loaded : [];
        }

        return $map[$key] ?? $en;
    }

    private function upsertBlock(string $existing, string $block, bool $yamlEquals): string
    {
        $body = trim($existing);
        $hadEquals = str_starts_with($body, '=') || $yamlEquals;
        if (str_starts_with($body, '=')) {
            $body = substr($body, 1);
        }
        $body = trim($body);

        if (str_contains($body, self::BLOCK_START) && str_contains($body, self::BLOCK_END)) {
            $body = preg_replace(
                '/' . preg_quote(self::BLOCK_START, '/') . '.*?' . preg_quote(self::BLOCK_END, '/') . '/s',
                $block,
                $body
            ) ?? ($body . '; ' . $block);
        } elseif ($body === '') {
            $body = $block;
        } else {
            if (!str_ends_with($body, ';')) {
                $body .= ';';
            }
            $body .= ' ' . $block;
        }

        $body = trim($body);

        return ($yamlEquals || $hadEquals) ? '=' . $body : $body;
    }

    /** @param list<ControlDocument> $documents
     * @return list<ControlNode>
     */
    private function findAllApps(array $documents): array
    {
        $apps = [];
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if ($control->isApp()) {
                    $apps[] = $control;
                }
            }
        }

        usort($apps, static function (ControlNode $a, ControlNode $b): int {
            $score = static function (ControlNode $c): int {
                if (str_contains($c->path, 'Src/App.')) {
                    return 0;
                }
                if (str_contains($c->path, 'Controls/')) {
                    return 1;
                }

                return 2;
            };

            return $score($a) <=> $score($b);
        });

        return $apps;
    }

    /** @param list<ControlDocument> $documents */
    private function pickIntroScreen(array $documents): ?ControlNode
    {
        $screens = [];
        foreach ($documents as $doc) {
            foreach ($doc->controls() as $control) {
                if ($control->isScreen()) {
                    $screens[] = $control;
                }
            }
        }
        if ($screens === []) {
            return null;
        }

        $score = static function (ControlNode $s): int {
            $n = strtolower($s->name);
            $score = 0;
            foreach (['settings', 'home', 'intro', 'welcome', 'start', 'landing', 'main', 'menu', 'topbar'] as $i => $needle) {
                if (str_contains($n, $needle)) {
                    $score += 100 - $i;
                }
            }
            foreach ($s->children as $child) {
                $cn = strtolower($child->name . ' ' . $child->type);
                if (str_contains($cn, 'lang') || str_contains($cn, 'setting') || str_contains($cn, 'radio')) {
                    $score += 20;
                }
            }

            return $score;
        };

        usort($screens, static fn(ControlNode $a, ControlNode $b): int => $score($b) <=> $score($a));

        return $screens[0];
    }

    private function looksLikeComponentDefinition(ControlNode $control): bool
    {
        $t = strtolower($control->type);

        return str_contains($t, 'canvascomponent')
            || str_contains($t, 'component')
            || ($control->getProperty('DefinitionType') !== null);
    }
}
