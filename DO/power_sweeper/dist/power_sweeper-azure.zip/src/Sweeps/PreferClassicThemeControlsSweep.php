<?php

declare(strict_types=1);

namespace PowerSweeper\Sweeps;

use PowerSweeper\ColorValue;
use PowerSweeper\ControlDocument;
use PowerSweeper\ControlNode;
use PowerSweeper\PowerFxFormulaSegments;
use PowerSweeper\Report;

/**
 * Swap modern / Fluent controls that lack Fill or Color onto classic templates
 * so enable_dark_mode can bind gblTheme backgrounds and text colors.
 */
final class PreferClassicThemeControlsSweep implements SweepInterface
{
    /** @var list<array<string, mixed>>|null */
    private static ?array $mapCache = null;

    public static function id(): string
    {
        return 'prefer_classic_theme_controls';
    }

    public static function label(): string
    {
        return 'Prefer classic controls for theming';
    }

    public static function description(): string
    {
        return 'Replace modern/Fluent controls that follow Appearance instead of Fill/Color with classic templates, then rewrite every formula reference (Self, screen-qualified, and cross-control) onto the classic property names so behavior stays the same. Run before enable_dark_mode.';
    }

    public function apply(array $documents, Report $report, array $options = []): void
    {
        $map = $this->loadMap($options);
        if ($map === []) {
            return;
        }

        $enabledOptional = [];
        foreach ($map as $entry) {
            $key = (string) ($entry['key'] ?? '');
            if ($key === '') {
                continue;
            }
            if (!empty($entry['optional'])) {
                $optName = 'include_' . $key;
                $enabledOptional[$key] = !empty($options[$optName]) || !empty($options['include_optional']);
            }
        }

        /** @var list<array{name:string,key:string}> $converted */
        $converted = [];
        foreach ($documents as $doc) {
            $touched = false;
            foreach ($doc->controls() as $control) {
                $entry = $this->matchEntry($control->type, $map);
                if ($entry === null) {
                    continue;
                }
                $key = (string) $entry['key'];
                if (!empty($entry['optional']) && empty($enabledOptional[$key])) {
                    continue;
                }
                if ($this->alreadyTarget($control, $entry)) {
                    continue;
                }
                // Chrome-less modern controls (transparent buttons, icons) stay modern.
                // Converting them to classic invents an opaque Fill and a larger Size.
                if ($this->shouldLeaveModern($control, $key)) {
                    continue;
                }

                $fromType = $control->type;
                $this->preserveClassicTextInputMode($control, $key, $report);
                $this->remapProperties($control, $entry, $report);
                $this->seedClassicInputFill($control, $key, $report);
                $this->preserveClassicPickerFields($control, $key, $report);
                $this->preserveClassicRadioDefault($control, $key, $report);
                $this->preserveClassicNumberFormat($control, $key, $report);
                $this->preserveModernButtonChrome($control, $key);
                $yaml = (string) $entry['yaml'];
                /** @var array{Id?:string,Name?:string,Version?:string} $json */
                $json = is_array($entry['json'] ?? null) ? $entry['json'] : [];
                $control->setControlType($yaml, $json);
                $report->add(self::id(), $control->path, 'Control', $fromType, $yaml);
                $converted[] = ['name' => $control->name, 'key' => $key];
                $touched = true;
            }
            if ($touched) {
                $doc->reindex();
            }
        }
        $this->rewriteConvertedRefs($documents, $converted, $report);
    }

    /**
     * @param array<string, mixed> $options
     * @return list<array<string, mixed>>
     */
    private function loadMap(array $options): array
    {
        if (isset($options['control_map']) && is_array($options['control_map'])) {
            return array_values($options['control_map']);
        }

        $file = isset($options['control_map_file']) && is_string($options['control_map_file'])
            ? $options['control_map_file']
            : dirname(__DIR__, 2) . '/config/theme_control_map.php';

        if (self::$mapCache !== null && !isset($options['control_map_file'])) {
            return self::$mapCache;
        }

        if (!is_file($file)) {
            return [];
        }

        /** @var mixed $loaded */
        $loaded = include $file;
        $map = is_array($loaded) ? array_values($loaded) : [];
        if (!isset($options['control_map_file'])) {
            self::$mapCache = $map;
        }
        return $map;
    }

    /**
     * @param list<array<string, mixed>> $map
     * @return array<string, mixed>|null
     */
    private function matchEntry(string $type, array $map): ?array
    {
        $haystack = strtolower(trim($type));
        if ($haystack === '' || str_starts_with($haystack, 'classic/')) {
            return null;
        }

        foreach ($map as $entry) {
            $patterns = $entry['match'] ?? [];
            if (!is_array($patterns)) {
                continue;
            }
            foreach ($patterns as $pattern) {
                if (!is_string($pattern) || $pattern === '') {
                    continue;
                }
                if (@preg_match($pattern, $haystack) === 1) {
                    return $entry;
                }
            }
        }
        return null;
    }

    /** @param array<string, mixed> $entry */
    private function alreadyTarget(ControlNode $control, array $entry): bool
    {
        $yaml = strtolower((string) ($entry['yaml'] ?? ''));
        $type = strtolower($control->type);
        if ($yaml !== '' && $type === $yaml) {
            return true;
        }
        $jsonName = strtolower((string) (($entry['json']['Name'] ?? '') ?: ''));
        if ($jsonName !== '' && ($type === $jsonName || str_ends_with($type, '/' . $jsonName))) {
            return true;
        }
        // Label@x is the modern_text target — don't re-match TextCanvas aliases incorrectly.
        if ($jsonName === 'label' && preg_match('#^label(?:@|$)#i', $control->type) === 1) {
            return true;
        }
        if ($jsonName === 'button' && preg_match('#^(?:classic/)?button@2\\.#i', $control->type) === 1) {
            return true;
        }
        if (in_array($jsonName, ['checkbox', 'toggle', 'radio', 'slider'], true)
            && preg_match('#^(?:classic/)?' . preg_quote($jsonName, '#') . '@2\\.#i', $control->type) === 1
        ) {
            return true;
        }
        return false;
    }

    /** @param array<string, mixed> $entry */
    private function remapProperties(ControlNode $control, array $entry, Report $report): void
    {
        $wasTransparent = $this->isTransparentAppearance($control->getProperty('Appearance'));
        $blankText = $this->isBlankButtonText($control->getProperty('Text'));
        $key = (string) ($entry['key'] ?? '');

        $map = $entry['property_map'] ?? [];
        if (is_array($map)) {
            foreach ($map as $fromProp => $toProp) {
                if (!is_string($fromProp) || !is_string($toProp) || $fromProp === '' || $toProp === '') {
                    continue;
                }
                $fromVal = $control->getProperty($fromProp);
                if ($fromVal === null || trim($fromVal) === '' || trim($fromVal) === '=') {
                    continue;
                }
                $existing = $control->getProperty($toProp);
                if ($existing !== null && trim($existing) !== '' && trim($existing) !== '=') {
                    // Transparent Fluent CTAs often keep a studio-white Fill while the real
                    // chrome lives on BasePaletteColor — prefer the palette when Fill is default.
                    $preferPalette = $fromProp === 'BasePaletteColor'
                        && $toProp === 'Fill'
                        && ColorValue::isStudioDefault((string) $existing, 'Fill');
                    if (!$preferPalette) {
                        continue;
                    }
                }
                $control->setProperty($toProp, $fromVal);
                $report->add(self::id(), $control->path, $toProp, $existing ?? '(unset)', $fromVal);
            }
        }

        $remove = $entry['remove'] ?? [];
        if (is_array($remove)) {
            foreach ($remove as $prop) {
                if (!is_string($prop) || $prop === '') {
                    continue;
                }
                $before = $control->getProperty($prop);
                if ($before === null) {
                    continue;
                }
                $control->removeProperty($prop);
                $report->add(self::id(), $control->path, $prop, $before, '(removed)');
            }
        }

        // Sidebar / gallery hit-targets use Transparent modern buttons over icons.
        // Classic buttons default to an opaque Fill and cover the glyph (black squares).
        if (($key === 'modern_button' || str_contains(strtolower($control->type), 'button'))
            && $wasTransparent
            && $blankText
        ) {
            $transparent = $control->format === 'yaml' ? '=RGBA(0, 0, 0, 0)' : 'RGBA(0, 0, 0, 0)';
            $fill = $control->getProperty('Fill');
            $fillStr = $fill !== null ? (string) $fill : '';
            if ($fillStr === '' || ColorValue::isStudioDefault($fillStr, 'Fill')) {
                $control->setProperty('Fill', $transparent);
                $report->add(self::id(), $control->path, 'Fill', $fillStr !== '' ? $fillStr : '(unset)', $transparent);
            }
        }
    }

    /**
     * Classic inputs default to an opaque studio fill when Fill is omitted.
     * Seed white so enable_dark_mode can wrap If(gblDarkMode, InputFill, white).
     */
    private function seedClassicInputFill(ControlNode $control, string $key, Report $report): void
    {
        if (!in_array($key, ['modern_text_input', 'modern_dropdown', 'modern_combobox', 'modern_datepicker', 'modern_number_input'], true)) {
            return;
        }
        $fill = $control->getProperty('Fill');
        $fillStr = $fill !== null ? trim((string) $fill) : '';
        if ($fillStr !== '' && $fillStr !== '=') {
            return;
        }
        $white = $control->format === 'yaml' ? '=RGBA(255, 255, 255, 1)' : 'RGBA(255, 255, 255, 1)';
        $control->setProperty('Fill', $white);
        $report->add(self::id(), $control->path, 'Fill', $fillStr !== '' ? $fillStr : '(unset)', $white);
    }

    /**
     * Classic TextInput uses TextMode.*, not TextInputType.*. Password / multiline
     * must survive the swap or the field becomes a single-line text box.
     */
    private function preserveClassicTextInputMode(ControlNode $control, string $key, Report $report): void
    {
        if ($key !== 'modern_text_input') {
            return;
        }
        $type = (string) ($control->getProperty('Type') ?? '');
        $mode = (string) ($control->getProperty('Mode') ?? '');
        $src = $type !== '' ? $type : $mode;
        $classic = null;
        if (preg_match('/Password/i', $src) === 1) {
            $classic = 'TextMode.Password';
        } elseif (preg_match('/MultiLine|Multiline/i', $src) === 1) {
            $classic = 'TextMode.MultiLine';
        }
        if ($classic !== null && (trim($mode) === '' || preg_match('/TextInputType/i', $mode) === 1)) {
            $to = $control->format === 'yaml' ? '=' . $classic : $classic;
            $control->setProperty('Mode', $to);
            $report->add(self::id(), $control->path, 'Mode', $mode !== '' ? $mode : '(unset)', $to);
        }
        if ($control->getProperty('Type') !== null) {
            $before = (string) $control->getProperty('Type');
            $control->removeProperty('Type');
            $report->add(self::id(), $control->path, 'Type', $before, '(removed)');
        }
    }

    /**
     * Classic ComboBox needs DisplayFields/SearchFields for primitive Items, and
     * DefaultSelectedItems as a record table ({Value: "A"}) not ["A"].
     */
    private function preserveClassicPickerFields(ControlNode $control, string $key, Report $report): void
    {
        if ($key !== 'modern_combobox' && $key !== 'modern_dropdown') {
            return;
        }
        if ($key === 'modern_combobox') {
            foreach (['DisplayFields', 'SearchFields'] as $prop) {
                $val = $control->getProperty($prop);
                if ($val !== null && trim((string) $val) !== '' && trim((string) $val) !== '=') {
                    continue;
                }
                $to = $control->format === 'yaml' ? '=["Value"]' : '["Value"]';
                $control->setProperty($prop, $to);
                $report->add(self::id(), $control->path, $prop, $val !== null ? (string) $val : '(unset)', $to);
            }
        }
        $defaults = $control->getProperty('DefaultSelectedItems');
        $wrapped = $this->wrapPrimitiveSelectedItems($defaults, $control->format === 'yaml');
        if ($wrapped !== null) {
            $control->setProperty('DefaultSelectedItems', $wrapped);
            $report->add(
                self::id(),
                $control->path,
                'DefaultSelectedItems',
                $defaults !== null ? (string) $defaults : '(unset)',
                $wrapped
            );
        }
    }

    /**
     * Classic Radio.Default is a scalar. Modern DefaultSelectedItems is often ["English"].
     */
    private function preserveClassicRadioDefault(ControlNode $control, string $key, Report $report): void
    {
        if ($key !== 'modern_radio') {
            return;
        }
        $defaults = $control->getProperty('DefaultSelectedItems');
        $wrapped = $this->wrapPrimitiveSelectedItems($defaults, $control->format === 'yaml');
        if ($wrapped !== null) {
            $control->setProperty('DefaultSelectedItems', $wrapped);
            $report->add(
                self::id(),
                $control->path,
                'DefaultSelectedItems',
                $defaults !== null ? (string) $defaults : '(unset)',
                $wrapped
            );
        }
        $existing = $control->getProperty('Default');
        if ($existing !== null && trim((string) $existing) !== '' && trim((string) $existing) !== '=') {
            return;
        }
        $src = $defaults !== null ? trim(ltrim(trim((string) $defaults), '=')) : '';
        $scalar = null;
        if (preg_match('/^\[\s*("[^"]*"|\'[^\']*\')\s*\]$/', $src, $m) === 1) {
            $scalar = $m[1];
        } elseif (preg_match('/^If\s*\((.+),\s*\[\s*("[^"]*"|\'[^\']*\')\s*\]\s*,\s*\[\s*("[^"]*"|\'[^\']*\')\s*\]\s*\)$/is', $src, $m) === 1) {
            $scalar = 'If(' . $m[1] . ', ' . $m[2] . ', ' . $m[3] . ')';
        }
        if ($scalar === null) {
            return;
        }
        $to = $control->format === 'yaml' ? '=' . $scalar : $scalar;
        $control->setProperty('Default', $to);
        $report->add(self::id(), $control->path, 'Default', $existing !== null ? (string) $existing : '(unset)', $to);
    }

    private function preserveClassicNumberFormat(ControlNode $control, string $key, Report $report): void
    {
        if ($key !== 'modern_number_input') {
            return;
        }
        $format = $control->getProperty('Format');
        if ($format !== null && trim((string) $format) !== '' && trim((string) $format) !== '=') {
            return;
        }
        $to = $control->format === 'yaml' ? '=TextFormat.Number' : 'TextFormat.Number';
        $control->setProperty('Format', $to);
        $report->add(self::id(), $control->path, 'Format', $format !== null ? (string) $format : '(unset)', $to);
    }

    /**
     * After a modern→classic swap, every formula that still names the modern
     * output/chrome properties must be rewritten or Studio breaks
     * (Checked, Label, Placeholder, Selected, .Value, FontColor, …).
     *
     * @param list<ControlDocument> $documents
     * @param list<array{name:string,key:string}> $converted
     */
    private function rewriteConvertedRefs(array $documents, array $converted, Report $report): void
    {
        if ($converted === []) {
            return;
        }
        foreach ($documents as $doc) {
            $doc->transformFormulas(function (string $formula, string $path) use ($converted, $report): string {
                $next = PowerFxFormulaSegments::transformCode($formula, function (string $code) use ($path, $converted): string {
                    foreach ($converted as $item) {
                        $code = $this->rewriteHostAndSelfRefs($code, $path, $item['name'], $item['key']);
                    }

                    return $code;
                }, false);
                if ($next === $formula) {
                    return $formula;
                }
                $report->add(self::id(), $path, 'Ref', self::preview($formula), self::preview($next));

                return $next;
            });
        }
    }

    private function rewriteHostAndSelfRefs(string $code, string $path, string $name, string $key): string
    {
        $host = $this->hostPattern($name);
        $self = $this->pathBelongsToControl($path, $name);
        $code = $this->rewriteSpecialHostRefs($code, $host, $key);
        if ($self) {
            $code = $this->rewriteSpecialSelfRefs($code, $key);
        }
        foreach ($this->refPropMap($key) as $from => $to) {
            $code = $this->rewriteMember($code, $host, $from, $to);
            if ($self) {
                $code = preg_replace('/\bSelf\.' . preg_quote($from, '/') . '\b/', 'Self.' . $to, $code) ?? $code;
            }
        }

        return $code;
    }

    private function rewriteSpecialHostRefs(string $code, string $host, string $key): string
    {
        $head = $this->hostHead($host);
        if ($key === 'modern_number_input') {
            $code = preg_replace(
                '/\bValue\s*\(\s*' . $head . '\.Value\s*\)/',
                'Value($1.Text)',
                $code
            ) ?? $code;
            $code = preg_replace('/' . $head . '\.Value\b/', 'Value($1.Text)', $code) ?? $code;

            return $code;
        }
        if ($key === 'modern_datepicker') {
            return preg_replace('/' . $head . '\.Value\b/', '$1.SelectedDate', $code) ?? $code;
        }
        if (in_array($key, ['modern_radio', 'modern_combobox', 'modern_dropdown'], true)) {
            $code = preg_replace('/' . $head . '\.Selected\b(?!\s*\.)/', '$1.Selected.Value', $code) ?? $code;
        }
        if (in_array($key, ['modern_combobox', 'modern_dropdown'], true)) {
            $code = preg_replace(
                '/\bin\s+' . $head . '\.SelectedItems\b(?!\s*\.)/',
                'in $1.SelectedItems.Value',
                $code
            ) ?? $code;
        }

        return $code;
    }

    private function rewriteSpecialSelfRefs(string $code, string $key): string
    {
        if ($key === 'modern_number_input') {
            $code = preg_replace('/\bValue\s*\(\s*Self\.Value\s*\)/', 'Value(Self.Text)', $code) ?? $code;
            $code = preg_replace('/\bSelf\.Value\b/', 'Value(Self.Text)', $code) ?? $code;

            return $code;
        }
        if ($key === 'modern_datepicker') {
            return preg_replace('/\bSelf\.Value\b/', 'Self.SelectedDate', $code) ?? $code;
        }
        if (in_array($key, ['modern_radio', 'modern_combobox', 'modern_dropdown'], true)) {
            $code = preg_replace('/\bSelf\.Selected\b(?!\s*\.)/', 'Self.Selected.Value', $code) ?? $code;
        }
        if (in_array($key, ['modern_combobox', 'modern_dropdown'], true)) {
            $code = preg_replace(
                '/\bin\s+Self\.SelectedItems\b(?!\s*\.)/',
                'in Self.SelectedItems.Value',
                $code
            ) ?? $code;
        }

        return $code;
    }

    private function rewriteMember(string $code, string $host, string $from, string $to): string
    {
        $head = $this->hostHead($host);

        return preg_replace('/' . $head . '\.' . preg_quote($from, '/') . '\b/', '$1.' . $to, $code) ?? $code;
    }

    /** Capture group 1 = optional screen qualifier + control name (quoted or bare). */
    private function hostHead(string $host): string
    {
        return '((?:(?:[A-Za-z_][\w]*|\'(?:[^\']|\'\')+\')\.)?' . $host . ')';
    }

    private function hostPattern(string $name): string
    {
        $quoted = "'(?:" . str_replace("'", "''", preg_quote($name, '/')) . ")'";
        if (preg_match('/^[A-Za-z_][\w]*$/', $name) === 1) {
            return '(?:(?<![A-Za-z_0-9])' . preg_quote($name, '/') . '\b|' . $quoted . ')';
        }

        return $quoted;
    }

    /** Simple member renames for formulas that read a converted control. */
    private function refPropMap(string $key): array
    {
        $shared = [
            'FontColor' => 'Color',
            'FontSize' => 'Size',
        ];

        return match ($key) {
            'modern_checkbox' => $shared + [
                'Checked' => 'Value',
                'Label' => 'Text',
                'BasePaletteColor' => 'Fill',
            ],
            'modern_toggle' => $shared + [
                'Checked' => 'Value',
                'Label' => 'TrueText',
                'BasePaletteColor' => 'TrueFill',
            ],
            'modern_text_input', 'modern_number_input' => $shared + [
                'Placeholder' => 'HintText',
                'PlaceholderText' => 'HintText',
                'BasePaletteColor' => 'Fill',
            ],
            'modern_button' => $shared + [
                'BasePaletteColor' => 'Fill',
            ],
            'modern_slider' => $shared + [
                'BasePaletteColor' => 'HandleFill',
            ],
            'modern_text', 'modern_dropdown', 'modern_combobox', 'modern_datepicker', 'modern_radio' => $shared + [
                'BasePaletteColor' => 'Fill',
            ],
            default => $shared,
        };
    }

    private function pathBelongsToControl(string $path, string $name): bool
    {
        return (bool) preg_match('/(?:^|[\\/#])' . preg_quote($name, '/') . '(?:[.\\/#]|$)/', $path);
    }

    private function wrapPrimitiveSelectedItems(?string $formula, bool $yaml): ?string
    {
        if ($formula === null) {
            return null;
        }
        $body = trim(ltrim(trim($formula), '='));
        if ($body === '' || str_contains($body, '{')) {
            return null;
        }
        if (preg_match('/^\[\s*(?:"[^"]*"|\'[^\']*\')(?:\s*,\s*(?:"[^"]*"|\'[^\']*\'))*\s*\]$/', $body) !== 1) {
            return null;
        }
        if (preg_match_all('/"[^"]*"|\'[^\']*\'/', $body, $m) < 1) {
            return null;
        }
        $records = [];
        foreach ($m[0] as $lit) {
            $records[] = '{Value: ' . $lit . '}';
        }
        $out = '[' . implode(', ', $records) . ']';

        return $yaml ? '=' . $out : $out;
    }

    private static function preview(string $value): string
    {
        $flat = preg_replace('/\s+/', ' ', $value) ?? $value;

        return strlen($flat) > 80 ? substr($flat, 0, 77) . '...' : $flat;
    }

    private function isTransparentAppearance(?string $appearance): bool
    {
        return is_string($appearance) && preg_match('/Transparent/i', $appearance) === 1;
    }

    private function isBlankButtonText(?string $text): bool
    {
        if ($text === null) {
            return true;
        }
        $trim = trim($text);
        if ($trim === '' || $trim === '=') {
            return true;
        }

        return preg_match('/^=\s*""\s*$/', $trim) === 1
            || preg_match("/^=\\s*''\\s*$/", $trim) === 1;
    }

    /**
     * Transparent / icon-only modern controls are layout chrome, not themed surfaces.
     * Leave them so dark mode can keep RGBA(0,0,0,0) instead of a classic Fill.
     */
    private function shouldLeaveModern(ControlNode $control, string $key): bool
    {
        if ($key === 'modern_icon') {
            return true;
        }
        // Modern text is already transparent chrome (loading titles, step numerals).
        // Classic Label invents an opaque Fill → black bars on light screens.
        if ($key === 'modern_text') {
            $fill = $control->getProperty('Fill');
            if ($fill === null || trim($fill) === '' || trim($fill) === '=') {
                return true;
            }
            $parsed = ColorValue::parse($fill);
            if ($parsed !== null && ColorValue::isTransparent($parsed)) {
                return true;
            }
        }
        $isButton = $key === 'modern_button' || str_contains(strtolower($control->type), 'button');
        if (!$isButton) {
            return false;
        }
        if ($this->isTransparentAppearance($control->getProperty('Appearance'))) {
            return true;
        }
        $fill = $control->getProperty('Fill');
        if ($fill === null || trim($fill) === '') {
            return false;
        }
        $parsed = ColorValue::parse($fill);

        return $parsed !== null && ColorValue::isTransparent($parsed);
    }

    /**
     * Classic buttons default Size=14 and a 2px black border. Copy modern FontSize
     * and drop the invented border. Do not invent Radius — keep the modern control's
     * corners (pixel-perfect). Self.Height / 2 turns every CTA into a pill.
     */
    private function preserveModernButtonChrome(ControlNode $control, string $key): void
    {
        if ($key !== 'modern_button' && !str_contains(strtolower($control->type), 'button')) {
            return;
        }
        $eq = $control->format === 'yaml';
        $size = $control->getProperty('Size');
        if ($size === null || trim($size) === '' || trim($size) === '=') {
            $fontSize = $control->getProperty('FontSize');
            if ($fontSize !== null && trim($fontSize) !== '' && trim($fontSize) !== '=') {
                $control->setProperty('Size', $fontSize);
            } else {
                $control->setProperty('Size', $eq ? '=10.5' : '10.5');
            }
        }

        $thickness = $control->getProperty('BorderThickness');
        $thicknessEmpty = $thickness === null || trim($thickness) === '' || trim($thickness) === '=';
        if ($thicknessEmpty) {
            $control->setProperty('BorderThickness', $eq ? '=0' : '0');
        }

        // Fluent Primary with no Radius still paints a capsule. Classic with no
        // Radius inherits that look. Pin a 4px rounded-rect (not Height/2).
        $radii = ['RadiusTopLeft', 'RadiusTopRight', 'RadiusBottomLeft', 'RadiusBottomRight'];
        $hasRadius = false;
        foreach ($radii as $prop) {
            $val = $control->getProperty($prop);
            if ($val !== null && trim($val) !== '' && trim($val) !== '=') {
                $hasRadius = true;
                break;
            }
        }
        if (!$hasRadius) {
            $radius = $eq ? '=4' : '4';
            foreach ($radii as $prop) {
                $control->setProperty($prop, $radius);
            }
        }
    }
}
