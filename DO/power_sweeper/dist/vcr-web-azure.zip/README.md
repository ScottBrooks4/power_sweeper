# Power Sweeper Web Package

Runtime: **php**  
Storage: **sql**  
Layout: **pixel**

## Drop onto a server

Unzip into the web root. Set the Azure startup command to:

```bash
bash /home/site/wwwroot/azure/startup.sh
```

Uses local SQL (`data/app.sqlite`). Set `SQL_DSN` for another SQL engine.
