<?php

declare(strict_types=1);

$configPath = dirname(__DIR__) . '/server/config.json';
$config = is_file($configPath)
    ? (json_decode((string) file_get_contents($configPath), true) ?: [])
    : [];
$storage = strtolower((string) ($config['storage'] ?? 'lom'));

require_once __DIR__ . '/TableMap.php';
require_once __DIR__ . '/LomStore.php';
require_once __DIR__ . '/SqlStore.php';
require_once __DIR__ . '/MailAllowlist.php';
require_once __DIR__ . '/MailGateway.php';
require_once __DIR__ . '/StoreSeed.php';

header('Content-Type: application/json; charset=utf-8');

$raw = file_get_contents('php://input');
$body = is_string($raw) && $raw !== '' ? (json_decode($raw, true) ?: []) : [];
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $body = array_merge($_GET, $body);
}
$action = (string) ($body['action'] ?? $_GET['action'] ?? 'list');
$table = (string) ($body['table'] ?? 'Items');

$root = dirname(__DIR__);
try {
    if ($action === 'invoke') {
        echo json_encode(handleInvoke($root, $config, $body), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return;
    }

    if (!TableMap::isPlausible($table)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'rejected table name']);
        return;
    }

    $store = $storage === 'sql'
        ? new SqlStore($root, $config)
        : new LomStore($root, $config);
    StoreSeed::ensure($store);

    $canonical = TableMap::canonical($table);
    $result = match ($action) {
        'list' => ['ok' => true, 'rows' => $store->list($table), 'table' => $canonical],
        'get' => ['ok' => true, 'row' => $store->get($table, $body['id'] ?? null), 'table' => $canonical],
        'insert' => ['ok' => true, 'row' => $store->insert($table, is_array($body['row'] ?? null) ? $body['row'] : []), 'table' => $canonical],
        'update' => ['ok' => true, 'row' => $store->update($table, is_array($body['row'] ?? null) ? $body['row'] : []), 'table' => $canonical],
        'delete' => ['ok' => true, 'deleted' => $store->delete($table, $body['id'] ?? null), 'table' => $canonical],
        'deleteWhere' => ['ok' => true, 'deleted' => $store->deleteWhere($table, is_array($body['match'] ?? null) ? $body['match'] : []), 'table' => $canonical],
        default => ['ok' => false, 'error' => 'unknown action'],
    };
    echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

/**
 * @param array<string, mixed> $config
 * @param array<string, mixed> $body
 * @return array<string, mixed>
 */
function handleInvoke(string $root, array $config, array $body): array
{
    $connector = (string) ($body['connector'] ?? '');
    $operation = (string) ($body['operation'] ?? '');
    $isMail = preg_match('/Outlook|SendEmail/i', $connector . $operation) === 1
        || preg_match('/SendEmailV2?/i', $operation) === 1;
    if (!$isMail) {
        return ['ok' => false, 'error' => 'unsupported invoke'];
    }

    $args = is_array($body['args'] ?? null) ? $body['args'] : [];
    $message = [
        'connector' => $connector !== '' ? $connector : 'Office365Outlook',
        'operation' => $operation !== '' ? $operation : 'SendEmailV2',
        'to' => (string) ($body['to'] ?? $args[0] ?? ''),
        'subject' => (string) ($body['subject'] ?? $args[1] ?? ''),
        'body' => (string) ($body['body'] ?? $args[2] ?? ''),
        'cc' => (string) ($body['cc'] ?? ''),
        'bcc' => (string) ($body['bcc'] ?? ''),
    ];
    $gateway = new MailGateway($root, $config, MailAllowlist::fromConfig($config));

    return $gateway->send($message);
}
